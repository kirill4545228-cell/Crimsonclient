package com.example.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.opengl.GL11;

public class DrawUtil {
    public static void fill(MatrixStack m, int x1, int y1, int x2, int y2, int c) {
        DrawableHelper.fill(m, x1, y1, x2, y2, c);
    }

    /** Прямоугольник со срезанными углами (имитация скругления). */
    public static void rrect(MatrixStack m, int x1, int y1, int x2, int y2, int c) {
        fill(m, x1 + 1, y1, x2 - 1, y2, c);
        fill(m, x1, y1 + 1, x2, y2 - 1, c);
    }

    /** Скруглённый прямоугольник с рамкой 1px (рамка и заливка не перекрываются). */
    public static void rrectOutline(MatrixStack m, int x1, int y1, int x2, int y2, int border, int fill) {
        fill(m, x1 + 1, y1, x2 - 1, y1 + 1, border);
        fill(m, x1 + 1, y2 - 1, x2 - 1, y2, border);
        fill(m, x1, y1 + 1, x1 + 1, y2 - 1, border);
        fill(m, x2 - 1, y1 + 1, x2, y2 - 1, border);
        rrect(m, x1 + 1, y1 + 1, x2 - 1, y2 - 1, fill);
    }

    public static void text(MatrixStack m, String s, float x, float y, int color, float scale, boolean shadow) {
        MinecraftClient mc = MinecraftClient.getInstance();
        m.push();
        m.scale(scale, scale, 1f);
        float inv = 1f / scale;
        if (shadow) mc.textRenderer.drawWithShadow(m, s, x * inv, y * inv, color);
        else mc.textRenderer.draw(m, s, x * inv, y * inv, color);
        m.pop();
    }

    public static int textWidth(String s, float scale) {
        return (int) (MinecraftClient.getInstance().textRenderer.getWidth(s) * scale);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Координаты в GUI-пикселях. */
    public static void scissor(int x, int y, int w, int h) {
        Window win = MinecraftClient.getInstance().getWindow();
        double s = win.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (x * s), (int) (win.getFramebufferHeight() - (y + h) * s), (int) (w * s), (int) (h * s));
    }

    public static void endScissor() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }
}
