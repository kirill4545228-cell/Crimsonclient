package com.example.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;

import java.util.HashMap;
import java.util.Map;

/** Белые иконки 32x32 из assets/mclient/textures/gui/icons, красятся в нужный цвет. */
public class Icons {
    private static final Map<String, Identifier> CACHE = new HashMap<>();

    public static void draw(MatrixStack m, String name, int x, int y, int size, int argb) {
        Identifier id = CACHE.computeIfAbsent(name, n -> new Identifier("mclient", "textures/gui/icons/" + n + ".png"));
        MinecraftClient.getInstance().getTextureManager().bindTexture(id);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.color4f(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f,
                (argb & 255) / 255f, ((argb >>> 24) & 255) / 255f);
        DrawableHelper.drawTexture(m, x, y, size, size, 0, 0, 32, 32, 32, 32);
        RenderSystem.color4f(1f, 1f, 1f, 1f);
    }
}
