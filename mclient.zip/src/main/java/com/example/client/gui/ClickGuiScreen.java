package com.example.client.gui;

import com.example.client.MClient;
import com.example.client.module.Category;
import com.example.client.module.Module;
import com.example.client.module.ModuleManager;
import com.example.client.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGuiScreen extends Screen {
    static final int W = 320, H = 232, HEADER = 28, SIDE = 32;
    static final int CARD_HEAD = 17, CARD_BODY = 27, GAP = 6, COL_GAP = 8;

    // запоминаем состояние между открытиями
    private static int wx = Integer.MIN_VALUE, wy;
    private static Category tab = Category.VISUALS;
    private static float scroll;

    private boolean dragWin;
    private double offX, offY;

    private interface CardVisitor {
        void visit(Module m, int x, int y, int w, int h);
    }

    public ClickGuiScreen() {
        super(new LiteralText(MClient.NAME));
    }

    @Override
    protected void init() {
        if (wx == Integer.MIN_VALUE) {
            wx = (width - W) / 2;
            wy = (height - H) / 2;
        }
    }

    // ---------- layout ----------
    private int cardW() {
        return (W - SIDE - 24 - COL_GAP) / 2;
    }

    private int contentX() {
        return wx + SIDE + 12;
    }

    private int cardH(Module m) {
        return CARD_HEAD + (m.expanded ? CARD_BODY : 1);
    }

    /** Обходит карточки текущей вкладки, возвращает общую высоту контента. */
    private int layout(CardVisitor v) {
        List<Module> mods = ModuleManager.byCategory(tab);
        int y = wy + HEADER + 15 - (int) scroll;
        int total = 0;
        for (int i = 0; i < mods.size(); i += 2) {
            Module a = mods.get(i);
            Module b = i + 1 < mods.size() ? mods.get(i + 1) : null;
            int h = cardH(a);
            if (b != null) h = Math.max(h, cardH(b));
            if (v != null) {
                v.visit(a, contentX(), y, cardW(), cardH(a));
                if (b != null) v.visit(b, contentX() + cardW() + COL_GAP, y, cardW(), cardH(b));
            }
            y += h + GAP;
            total += h + GAP;
        }
        return total;
    }

    private float maxScroll() {
        return Math.max(0, layout(null) + 15 - (H - HEADER));
    }

    // ---------- render ----------
    @Override
    public void render(MatrixStack m, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        scroll = Math.max(0, Math.min(scroll, maxScroll()));

        DrawUtil.rrectOutline(m, wx, wy, wx + W, wy + H, Colors.BORDER, Colors.WIN_BG);
        DrawUtil.fill(m, wx + 1, wy + HEADER, wx + SIDE, wy + H - 1, Colors.SIDE_BG);
        DrawUtil.fill(m, wx + 1, wy + HEADER - 1, wx + W - 1, wy + HEADER, Colors.BORDER);
        DrawUtil.fill(m, wx + SIDE, wy + HEADER, wx + SIDE + 1, wy + H - 1, Colors.BORDER);

        // шапка
        button(m, wx + 7, wy + 6, 17, 16, "home", mx, my);
        button(m, wx + 30, wy + 6, 17, 16, "search", mx, my);
        int tw = DrawUtil.textWidth(tab.label, 1f) + 12;
        DrawUtil.rrectOutline(m, wx + 53, wy + 6, wx + 53 + tw, wy + 22, Colors.BTN_BORDER, Colors.BTN_BG);
        DrawUtil.text(m, tab.label, wx + 59, wy + 10, Colors.TEXT_DIM, 1f, false);

        // профиль
        int px = wx + W - 59, py = wy + 7;
        DrawUtil.rrectOutline(m, px, py, px + 53, py + 15, Colors.BTN_BORDER, Colors.BTN_BG);
        DrawUtil.rrect(m, px + 4, py + 3, px + 13, py + 12, 0xFF2B2327);
        DrawUtil.text(m, mc.getSession().getUsername(), px + 17, py + 3, Colors.TEXT_DIM, 0.6f, false);
        DrawUtil.text(m, "USER", px + 17, py + 8, Colors.ACCENT, 0.6f, false);

        // сайдбар
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int ix = wx + 7, iy = wy + 46 + i * 25;
            boolean sel = cats[i] == tab, hov = DrawUtil.in(mx, my, ix, iy, 17, 17);
            if (sel) DrawUtil.rrectOutline(m, ix, iy, ix + 17, iy + 17, Colors.ACCENT, Colors.BTN_BG);
            Icons.draw(m, cats[i].icon, ix + 3, iy + 3, 11, sel ? Colors.ACCENT : hov ? Colors.TEXT : Colors.TEXT_DIM);
        }

        // карточки
        DrawUtil.scissor(wx + SIDE + 1, wy + HEADER, W - SIDE - 2, H - HEADER - 1);
        layout((mod, x, y, w, h) -> drawCard(m, mod, x, y, w, h));
        DrawUtil.endScissor();

        super.render(m, mx, my, delta);
    }

    private void button(MatrixStack m, int x, int y, int w, int h, String icon, int mx, int my) {
        boolean hov = DrawUtil.in(mx, my, x, y, w, h);
        DrawUtil.rrectOutline(m, x, y, x + w, y + h, hov ? Colors.ACCENT : Colors.BTN_BORDER, Colors.BTN_BG);
        Icons.draw(m, icon, x + (w - 8) / 2, y + (h - 8) / 2, 8, Colors.TEXT_DIM);
    }

    private void drawCard(MatrixStack m, Module mod, int x, int y, int w, int h) {
        int border = mod.enabled ? Colors.ACCENT : Colors.DIM_BORDER;
        DrawUtil.rrectOutline(m, x, y, x + w, y + h, border, Colors.CARD_BG);
        DrawUtil.fill(m, x + 1, y + 1, x + w - 1, y + CARD_HEAD, Colors.CARD_HEADER);
        Icons.draw(m, mod.expanded ? "up" : "down", x + 5, y + 5, 7, Colors.TEXT_DIM);
        DrawUtil.text(m, mod.name, x + 16, y + 5, Colors.TEXT, 1f, false);

        int bw = DrawUtil.textWidth(mod.bind, 0.75f) + 6;
        int bx = x + w - bw - 4;
        DrawUtil.rrect(m, bx, y + 3, bx + bw, y + 14, Colors.BADGE);
        DrawUtil.text(m, mod.bind, bx + 3, y + 6, Colors.TEXT_DIM, 0.75f, false);

        if (mod.expanded) {
            int ry = y + CARD_HEAD;
            DrawUtil.text(m, "Enable", x + 8, ry + (CARD_BODY - 8) / 2f, Colors.TEXT, 1f, false);
            int cx = x + w - 14, cy = ry + (CARD_BODY - 9) / 2;
            if (mod.enabled) {
                DrawUtil.rrect(m, cx, cy, cx + 9, cy + 9, Colors.ACCENT);
                Icons.draw(m, "check", cx + 1, cy + 1, 7, Colors.TEXT);
            } else {
                DrawUtil.rrectOutline(m, cx, cy, cx + 9, cy + 9, Colors.ACCENT, Colors.CARD_BG);
            }
        }
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        if (DrawUtil.in(mx, my, wx + 7, wy + 6, 17, 16)) {
            tab = Category.VISUALS;
            scroll = 0;
            return true;
        }
        if (DrawUtil.in(mx, my, wx + 30, wy + 6, 17, 16)) return true; // поиск — позже

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (DrawUtil.in(mx, my, wx + 7, wy + 46 + i * 25, 17, 17)) {
                tab = cats[i];
                scroll = 0;
                return true;
            }
        }

        if (DrawUtil.in(mx, my, wx + SIDE + 1, wy + HEADER, W - SIDE - 2, H - HEADER - 1)) {
            final boolean[] hit = {false};
            layout((mod, x, y, w, h) -> {
                if (hit[0] || !DrawUtil.in(mx, my, x, y, w, h)) return;
                hit[0] = true;
                if (my < y + CARD_HEAD) mod.expanded = !mod.expanded;
                else mod.toggle();
            });
            if (hit[0]) return true;
        }

        if (DrawUtil.in(mx, my, wx, wy, W, HEADER)) {
            dragWin = true;
            offX = mx - wx;
            offY = my - wy;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragWin && button == 0) {
            wx = (int) (mx - offX);
            wy = (int) (my - offY);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragWin = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll = Math.max(0, Math.min(scroll - (float) amount * 14f, maxScroll()));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
