package com.example.client.util;

public class Colors {
    public static final int ACCENT = 0xFFFF1A5C;
    public static final int WIN_BG = 0xFF11070B;
    public static final int SIDE_BG = 0xFF0C0508;
    public static final int BORDER = 0xFF2A1219;
    public static final int BTN_BG = 0xFF1A1014;
    public static final int BTN_BORDER = 0xFF3A2A30;
    public static final int CARD_BG = 0xFF150A0E;
    public static final int CARD_HEADER = 0xFF1D1519;
    public static final int BADGE = 0xFF2B2327;
    public static final int DIM_BORDER = 0xFF3A2A30;
    public static final int CHIP_BG = 0xD0120A0E;
    public static final int CHIP_BORDER = 0xFF2E2328;
    public static final int TEXT = 0xFFFFFFFF;
    public static final int TEXT_DIM = 0xFF9A9A9A;
}
