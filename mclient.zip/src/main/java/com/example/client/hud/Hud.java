package com.example.client.hud;

import com.example.client.MClient;
import com.example.client.gui.DrawUtil;
import com.example.client.gui.Icons;
import com.example.client.module.Module;
import com.example.client.module.ModuleManager;
import com.example.client.util.Colors;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class Hud {
    private static int frames, fps;
    private static long lastFps = System.currentTimeMillis();
    private static double bps, px, pz;

    private static class Seg {
        final String icon, text;
        final int iconColor;

        Seg(String icon, String text, int iconColor) {
            this.icon = icon;
            this.text = text;
            this.iconColor = iconColor;
        }
    }

    public static void init() {
        HudRenderCallback.EVENT.register(Hud::render);
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (c.player == null) {
                bps = 0;
                return;
            }
            double dx = c.player.getX() - px, dz = c.player.getZ() - pz;
            px = c.player.getX();
            pz = c.player.getZ();
            bps = bps * 0.8 + Math.hypot(dx, dz) * 20 * 0.2;
        });
    }

    private static void render(MatrixStack m, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.debugEnabled) return;

        frames++;
        long now = System.currentTimeMillis();
        if (now - lastFps >= 1000) {
            fps = frames;
            frames = 0;
            lastFps = now;
        }

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int a = Colors.ACCENT;

        // верхние виджеты
        widget(m, 120, 9, "CoolDowns", "clock");
        widget(m, 210, 9, "Potions", "potion");
        widget(m, 300, 9, "HotKeys", "keyboard");

        // вотермарк
        DrawUtil.rrectOutline(m, 57, 56, 73, 72, Colors.CHIP_BORDER, Colors.CHIP_BG);
        Icons.draw(m, "logo", 61, 60, 8, a);
        chip(m, 76, 56, new Seg(null, MClient.NAME.toUpperCase(), a), new Seg("badge", "USER", Colors.TEXT_DIM),
                new Seg("user", mc.getSession().getUsername(), Colors.TEXT_DIM),
                new Seg("monitor", fps + " FPS", Colors.TEXT_DIM));

        String server = mc.isInSingleplayer() ? "Singleplayer"
                : (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "Server");
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        chip(m, 57, 76, new Seg("server", server, Colors.TEXT_DIM), new Seg("wifi", ping + " ms", Colors.TEXT_DIM));

        // инвентарь
        inventory(m, Math.max(0, sw - 148 - 100), 49, mc);

        // нижние чипы
        int x = 3, y = sh - 19;
        x += chip(m, x, y, new Seg("bolt", String.format(Locale.US, "%.1f BPS", bps), a)) + 4;
        x += chip(m, x, y, new Seg("chart", "20.0 TPS", a)) + 4; // TPS пока заглушка
        chip(m, x, y, new Seg("compass", (int) Math.floor(mc.player.getX()) + ", "
                + (int) Math.floor(mc.player.getY()) + ", " + (int) Math.floor(mc.player.getZ()), a));

        // список модулей справа
        TextRenderer tr = mc.textRenderer;
        List<Module> active = new ArrayList<>();
        for (Module mod : ModuleManager.MODULES) if (mod.enabled) active.add(mod);
        active.sort(Comparator.comparingInt((Module mod) -> tr.getWidth(mod.name)).reversed());
        int ry = 4;
        for (Module mod : active) {
            int w = tr.getWidth(mod.name);
            tr.drawWithShadow(m, mod.name, sw - w - 6, ry + 1, a);
            DrawUtil.fill(m, sw - 2, ry, sw, ry + 11, a);
            ry += 11;
        }
    }

    private static int chip(MatrixStack m, int x, int y, Seg... segs) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int pad = 5, w = pad * 2 + (segs.length - 1) * 11;
        for (Seg s : segs) w += (s.icon != null ? 11 : 0) + tr.getWidth(s.text);
        DrawUtil.rrectOutline(m, x, y, x + w, y + 16, Colors.CHIP_BORDER, Colors.CHIP_BG);
        int cx = x + pad;
        for (int i = 0; i < segs.length; i++) {
            Seg s = segs[i];
            if (s.icon != null) {
                Icons.draw(m, s.icon, cx, y + 4, 8, s.iconColor);
                cx += 11;
            }
            boolean accentText = s.icon == null;
            tr.draw(m, s.text, cx, y + 4, accentText ? s.iconColor : Colors.TEXT);
            cx += tr.getWidth(s.text);
            if (i < segs.length - 1) {
                DrawUtil.fill(m, cx + 5, y + 3, cx + 6, y + 13, Colors.CHIP_BORDER);
                cx += 11;
            }
        }
        return w;
    }

    private static void widget(MatrixStack m, int x, int y, String title, String icon) {
        DrawUtil.rrectOutline(m, x, y, x + 80, y + 23, Colors.CHIP_BORDER, Colors.CHIP_BG);
        DrawUtil.fill(m, x + 1, y + 1, x + 79, y + 16, 0xE01A1216);
        DrawUtil.text(m, title, x + 6, y + 5, Colors.TEXT, 1f, false);
        Icons.draw(m, icon, x + 80 - 14, y + 4, 8, Colors.ACCENT);
    }

    private static void inventory(MatrixStack m, int x, int y, MinecraftClient mc) {
        int w = 148, h = 16 + 48 + 4;
        DrawUtil.rrectOutline(m, x, y, x + w, y + h, Colors.CHIP_BORDER, Colors.CHIP_BG);
        DrawUtil.fill(m, x + 1, y + 1, x + w - 1, y + 16, 0xE01A1216);
        DrawUtil.text(m, "Inventory", x + 6, y + 5, Colors.TEXT, 1f, false);
        Icons.draw(m, "cube", x + w - 14, y + 4, 8, Colors.ACCENT);
        for (int i = 9; i < 36; i++) {
            ItemStack st = mc.player.inventory.getStack(i);
            if (st.isEmpty()) continue;
            int sx = x + 2 + ((i - 9) % 9) * 16, sy = y + 18 + ((i - 9) / 9) * 16;
            mc.getItemRenderer().renderGuiItemIcon(st, sx, sy);
            mc.getItemRenderer().renderGuiItemOverlay(mc.textRenderer, st, sx, sy);
        }
    }
}
