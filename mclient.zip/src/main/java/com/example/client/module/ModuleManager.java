package com.example.client.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        add(Category.VISUALS, true, "Friends Target Render", "Hands Shader", "Jump Circles", "Target Render",
                "China Hat", "Trails", "Block Highlight", "Hitboxes", "Ambient Particles", "Totem Particles",
                "Hands Tweaks", "End Crystals", "Hit Particles", "Fake Player", "Hit Bubbles", "Hit Sounds",
                "Kill Effect");
        add(Category.COMBAT, false, "KillAura", "Velocity", "Criticals", "AutoClicker", "Reach", "AutoTotem");
        add(Category.MOVEMENT, false, "Sprint", "Speed", "Fly", "NoFall", "Step", "Spider");
        add(Category.PLAYER, false, "AutoTool", "FastPlace", "Scaffold", "ChestStealer");
        add(Category.PLAYER, true, "KeyBind", "Trinket");
        add(Category.WORLD, true, "World");
        add(Category.WORLD, false, "Fullbright", "Weather", "Time Changer", "Fog");
        add(Category.MISC, true, "HUD");
        add(Category.MISC, false, "AutoRespawn", "Spammer", "FakeLag");
        add(Category.THEME, true, "Theme");
        add(Category.THEME, false, "Rainbow", "Gradient");
    }

    private static void add(Category c, boolean on, String... names) {
        for (String n : names) MODULES.add(new Module(n, c, on));
    }

    public static List<Module> byCategory(Category c) {
        List<Module> r = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) r.add(m);
        return r;
    }
}
