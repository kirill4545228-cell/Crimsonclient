package com.example.client.module;

public enum Category {
    VISUALS("Visuals", "eye"),
    COMBAT("Combat", "crosshair"),
    MOVEMENT("Movement", "sparkle"),
    PLAYER("Player", "user"),
    WORLD("World", "hex"),
    MISC("Misc", "grid"),
    THEME("Theme", "drop");

    public final String label;
    public final String icon;

    Category(String label, String icon) {
        this.label = label;
        this.icon = icon;
    }
}
