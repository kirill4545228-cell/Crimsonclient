package com.example.client.module;

/** Пока только визуальная заготовка: логики нет. */
public class Module {
    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean expanded = true;
    public String bind = "N/A";

    public Module(String name, Category category, boolean enabled) {
        this.name = name;
        this.category = category;
        this.enabled = enabled;
    }

    public void toggle() {
        enabled = !enabled;
    }
}
