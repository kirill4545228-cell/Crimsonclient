package com.example.client;

import com.example.client.gui.ClickGuiScreen;
import com.example.client.hud.Hud;
import com.example.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class MClient implements ClientModInitializer {
    public static final String NAME = "MClient";
    public static final String VERSION = "0.1";
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Hud.init();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Open ClickGUI", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, NAME));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.openScreen(new ClickGuiScreen());
                }
            }
        });
    }
}
