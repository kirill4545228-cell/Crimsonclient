package dev.vclient.module;

public enum Category {
    VISUALS("Visuals", "V"),
    COMBAT("Combat", "C"),
    MOVEMENT("Movement", "M"),
    PLAYER("Player", "P"),
    WORLD("World", "W"),
    MISC("Misc", "X"),
    SETTINGS("Settings", "S");

    public final String title;
    public final String icon;

    Category(String title, String icon) {
        this.title = title;
        this.icon = icon;
    }
}
