package dev.vclient.module;

public enum Page {
    COMBAT(Group.COMBAT, "Combat"),
    MOVEMENT(Group.PLAYER, "Movement"),
    PLAYER(Group.PLAYER, "Player"),
    ESP(Group.VISUALS, "ESP"),
    RENDER(Group.VISUALS, "Render"),
    DISPLAY(Group.VISUALS, "Display");

    public final Group group;
    public final String title;

    Page(Group group, String title) {
        this.group = group;
        this.title = title;
    }
}
