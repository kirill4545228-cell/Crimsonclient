package dev.vclient.module;

public enum Page {
    COMBAT(Group.COMBAT, "Combat"),
    ESP(Group.VISUALS, "ESP"),
    DISPLAY(Group.VISUALS, "Display");

    public final Group group;
    public final String title;

    Page(Group group, String title) {
        this.group = group;
        this.title = title;
    }
}
