package dev.vclient.module;

public enum Page {
    COMBAT(Group.COMBAT, "Combat"),
    RENDER(Group.VISUALS, "Render"),
    ESP(Group.VISUALS, "ESP"),
    DISPLAY(Group.VISUALS, "Display"),
    PLAYER(Group.PLAYER, "Player"),
    MOVEMENT(Group.PLAYER, "Movement"),
    CONFIGS(Group.SETTINGS, "Configs"),
    MISC(Group.SETTINGS, "Miscellaneous");

    public final Group group;
    public final String title;

    Page(Group group, String title) {
        this.group = group;
        this.title = title;
    }
}
