package dev.vclient.module;

import java.util.Locale;

public class Setting {
    public final String name;
    public final boolean slider;
    public boolean value;
    public double num, min, max;
    public float anim;

    private Setting(String name, boolean slider) {
        this.name = name;
        this.slider = slider;
    }

    public static Setting bool(String name, boolean v) {
        Setting s = new Setting(name, false);
        s.value = v;
        s.anim = v ? 1f : 0f;
        return s;
    }

    public static Setting slider(String name, double v, double min, double max) {
        Setting s = new Setting(name, true);
        s.num = v;
        s.min = min;
        s.max = max;
        return s;
    }

    public double step() {
        return (max - min) >= 20 ? 1.0 : 0.1;
    }

    public String display() {
        return (max - min) >= 20
                ? String.format(Locale.US, "%.0f", num)
                : String.format(Locale.US, "%.1f", num);
    }
}
