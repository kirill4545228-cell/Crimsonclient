package dev.vclient.module;

public class Module {
    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean expanded = true;
    public String bind = "N/A";

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }
}
