package dev.vclient.module;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final String desc;
    public final Page page;
    public boolean enabled;
    public boolean expanded;
    public float anim;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, String desc, Page page) {
        this.name = name;
        this.desc = desc;
        this.page = page;
    }

    public Module add(Setting s) {
        settings.add(s);
        return this;
    }

    public Module on() {
        enabled = true;
        anim = 1f;
        return this;
    }

    public boolean getBool(String settingName) {
        for (Setting s : settings) {
            if (!s.slider && s.name.equals(settingName)) return s.value;
        }
        return false;
    }

    public double num(String settingName) {
        for (Setting s : settings) {
            if (s.slider && !s.color && s.name.equals(settingName)) return s.num;
        }
        return 0;
    }

    public int color(String settingName) {
        for (Setting s : settings) {
            if (s.color && s.name.equals(settingName)) return s.rgb();
        }
        return 0xFFFFFF;
    }
}
