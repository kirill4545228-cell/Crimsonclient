package dev.vclient.module;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> ALL = new ArrayList<>();

    private static Module reg(Page p, String name, String desc) {
        Module m = new Module(name, desc, p);
        ALL.add(m);
        return m;
    }

    static {
        // Combat (только меню, без логики)
        reg(Page.COMBAT, "Attack Aura", "Автоматически бьёт игроков вокруг")
                .add(Setting.slider("Дистанция", 3.0, 2, 6))
                .add(Setting.bool("Только игроки", true));
        reg(Page.COMBAT, "Aim Assist", "Помощник прицеливания")
                .add(Setting.slider("Плавность", 50, 0, 100));
        reg(Page.COMBAT, "Trigger Bot", "Автоматически бьёт того, на кого вы смотрите")
                .add(Setting.slider("Задержка, мс", 100, 0, 500));
        reg(Page.COMBAT, "Tape Mouse", "Беспрерывная атака");
        reg(Page.COMBAT, "Trident Clicker", "Закликивание трезубцем");
        reg(Page.COMBAT, "No Entity Trace", "Отключает трассировку сущностей, позволяя взаимодействовать сквозь них");
        reg(Page.COMBAT, "Hit Boxes", "Расширяет хит-боксы сущностей")
                .add(Setting.slider("Размер", 0.2, 0, 1));
        reg(Page.COMBAT, "Auto Armor", "Автоматически надевает лучшую броню");
        reg(Page.COMBAT, "Item Helper", "Быстрое использование предметов по биндам");
        reg(Page.COMBAT, "Auto Swap", "Меняет предметы при прожатии")
                .add(Setting.bool("Только в хотбаре", true));

        // Render
        reg(Page.RENDER, "Target Render", "Красивая отрисовка выбранной цели")
                .add(Setting.bool("Анимация", true))
                .add(Setting.slider("Размер", 1.0, 0.5, 2));
        reg(Page.RENDER, "Jump Circles", "Круги на земле при прыжке")
                .add(Setting.slider("Время жизни", 1.5, 0.5, 5));
        reg(Page.RENDER, "China Hat", "Китайская шляпа над головой");
        reg(Page.RENDER, "Trails", "След за игроком при движении")
                .add(Setting.slider("Длина", 20, 5, 60));
        reg(Page.RENDER, "Block Highlight", "Подсветка блока, на который вы смотрите");
        reg(Page.RENDER, "Hit Bubbles", "Пузыри над целью при ударе");
        reg(Page.RENDER, "Hit Particles", "Дополнительные частицы при ударе");
        reg(Page.RENDER, "Kill Effect", "Эффект при убийстве игрока");
        reg(Page.RENDER, "Hands Shader", "Шейдер для рук от первого лица");
        reg(Page.RENDER, "Hand Tweaks", "Настройка положения и размера рук");

        // ESP
        reg(Page.ESP, "Friends Target Render", "Отдельная подсветка для друзей");
        reg(Page.ESP, "Nametags", "Увеличенные и читаемые ники игроков");
        reg(Page.ESP, "Item ESP", "Подсветка выпавших предметов");
        reg(Page.ESP, "Storage ESP", "Подсветка сундуков и других контейнеров");

        // Display
        reg(Page.DISPLAY, "HUD", "Информационные плашки: ник, FPS, пинг, координаты и список модулей").on()
                .add(Setting.bool("Информация", true))
                .add(Setting.bool("Координаты", true))
                .add(Setting.bool("Список модулей", true));
        reg(Page.DISPLAY, "Armor HUD", "Показывает состояние брони на экране");
        reg(Page.DISPLAY, "Potions", "Список активных эффектов зелий");
        reg(Page.DISPLAY, "Cooldowns", "Перезарядка предметов на экране");
        reg(Page.DISPLAY, "HotKeys", "Список назначенных биндов");

        // Player
        reg(Page.PLAYER, "Fake Player", "Создаёт клиентскую копию вашего игрока");
        reg(Page.PLAYER, "Auto Tool", "Автоматически выбирает лучший инструмент");

        // Movement
        reg(Page.MOVEMENT, "Sprint", "Постоянный бег без зажатия клавиши");
        reg(Page.MOVEMENT, "Safe Walk", "Не даёт упасть с края блока");

        // Configs
        reg(Page.CONFIGS, "Auto Save", "Автоматически сохраняет конфиг при выходе из игры").on();
        reg(Page.CONFIGS, "Default Config", "Загружает конфиг по умолчанию при запуске");

        // Misc
        reg(Page.MISC, "Streamer Mode", "Скрывает ник и личные данные на экране");
        reg(Page.MISC, "Language", "Язык интерфейса клиента");
    }

    private ModuleManager() {}

    public static List<Module> all() {
        return ALL;
    }

    public static List<Module> get(Page p) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.page == p) out.add(m);
        return out;
    }

    public static Module get(String name) {
        for (Module m : ALL) if (m.name.equals(name)) return m;
        return null;
    }

    public static boolean isEnabled(String name) {
        Module m = get(name);
        return m != null && m.enabled;
    }
}
