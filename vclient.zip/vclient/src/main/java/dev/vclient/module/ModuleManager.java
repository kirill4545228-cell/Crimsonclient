package dev.vclient.module;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> ALL = new ArrayList<>();

    static {
        String[] visuals = {
                "Friends Target Render", "Hands Shader", "Jump Circles", "Target Render",
                "China Hat", "Trails", "Block Highlight", "Hitboxes",
                "Ambient Particles", "Totem Particles", "Hand Tweaks", "End Crystals",
                "Hit Particles", "Fake Player", "Hit Bubbles", "Hit Sounds",
                "Kill Effect", "KeyBind", "Trinket", "Theme", "World", "HUD"
        };
        for (String n : visuals) {
            ALL.add(new Module(n, Category.VISUALS));
        }
        get("HUD").enabled = true;
    }

    private ModuleManager() {}

    public static List<Module> all() {
        return ALL;
    }

    public static List<Module> get(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static Module get(String name) {
        for (Module m : ALL) if (m.name.equals(name)) return m;
        return null;
    }

    public static boolean isEnabled(String name) {
        Module m = get(name);
        return m != null && m.enabled;
    }
}
