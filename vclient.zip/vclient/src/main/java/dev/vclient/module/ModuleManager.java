package dev.vclient.module;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> ALL = new ArrayList<>();

    private static Module reg(Page p, String name, String desc) {
        Module m = new Module(name, desc, p);
        ALL.add(m);
        return m;
    }

    private static Module targets(Module m) {
        return m.add(Setting.bool("Игроки", true))
                .add(Setting.bool("Мобы", true))
                .add(Setting.bool("Животные", false));
    }

    static {
        // Combat
        targets(reg(Page.COMBAT, "Aimbot", "Автоматически наводится на голову ближайшей цели в бою")
                .add(Setting.slider("Дистанция", 6.0, 2, 10))
                .add(Setting.slider("FOV", 90, 10, 180))
                .add(Setting.slider("Скорость", 8, 1, 20)))
                .add(Setting.bool("Только при ЛКМ", false));

        targets(reg(Page.COMBAT, "Trigger Bot", "Автоматически бьёт того, на кого вы смотрите")
                .add(Setting.slider("Задержка, мс", 100, 0, 500))
                .add(Setting.bool("Ждать кулдаун", true)));

        // ESP
        targets(reg(Page.ESP, "Entity ESP", "Подсветка игроков и мобов сквозь стены, цвет можно выбрать")
                .add(Setting.color("Цвет", 0.97))
                .add(Setting.slider("Дистанция", 64, 16, 128))
                .add(Setting.bool("Заливка", true)));

        // Display
        reg(Page.DISPLAY, "HUD", "Информационные плашки: ник, FPS, пинг, координаты и список модулей").on()
                .add(Setting.bool("Информация", true))
                .add(Setting.bool("Координаты", true))
                .add(Setting.bool("Список модулей", true));
    }

    private ModuleManager() {}

    public static List<Module> all() {
        return ALL;
    }

    public static List<Module> get(Page p) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.page == p) out.add(m);
        return out;
    }

    public static Module get(String name) {
        for (Module m : ALL) if (m.name.equals(name)) return m;
        return null;
    }

    public static boolean isEnabled(String name) {
        Module m = get(name);
        return m != null && m.enabled;
    }
}
