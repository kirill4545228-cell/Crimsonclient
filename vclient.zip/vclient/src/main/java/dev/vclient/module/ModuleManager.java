package dev.vclient.module;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> ALL = new ArrayList<>();

    private static Module reg(Page p, String name, String desc) {
        Module m = new Module(name, desc, p);
        ALL.add(m);
        return m;
    }

    private static Module targets(Module m) {
        return m.add(Setting.bool("Игроки", true))
                .add(Setting.bool("Мобы", true))
                .add(Setting.bool("Животные", false));
    }

    static {
        // ---------------- Combat ----------------
        targets(reg(Page.COMBAT, "Aimbot", "Автоматически наводится на голову ближайшей цели в бою")
                .add(Setting.slider("Дистанция", 6.0, 2, 10))
                .add(Setting.slider("FOV", 90, 10, 180))
                .add(Setting.slider("Скорость", 8, 1, 20)))
                .add(Setting.bool("Только при ЛКМ", false));

        targets(reg(Page.COMBAT, "BowAimbot", "Рассчитывает траекторию выстрела из лука с упреждением по движению цели")
                .add(Setting.slider("Дистанция", 60, 10, 120))
                .add(Setting.slider("FOV", 60, 10, 180))
                .add(Setting.slider("Скорость", 10, 1, 20))
                .add(Setting.bool("Предсказание", true)));

        targets(reg(Page.COMBAT, "Trigger Bot", "Автоматически бьёт того, на кого вы смотрите")
                .add(Setting.slider("Задержка, мс", 100, 0, 500))
                .add(Setting.bool("Ждать кулдаун", true)));

        targets(reg(Page.COMBAT, "HitBox", "Увеличивает область попадания по цели для точности")
                .add(Setting.slider("Размер", 0.2, 0, 1)));

        targets(reg(Page.COMBAT, "KillAura", "Бьёт мобов, игроков и животных в зоне действия")
                .add(Setting.slider("Дистанция", 4.0, 2, 6))
                .add(Setting.slider("Задержка, мс", 0, 0, 500))
                .add(Setting.bool("Ждать кулдаун", true))
                .add(Setting.bool("Через стены", false)));

        targets(reg(Page.COMBAT, "LegitAura", "Как KillAura, но с плавной настраиваемой доводкой до цели")
                .add(Setting.slider("Дистанция", 3.5, 2, 6))
                .add(Setting.slider("FOV", 120, 30, 180))
                .add(Setting.slider("Скорость", 7, 1, 20))
                .add(Setting.slider("Рандомизация", 0.5, 0, 3))
                .add(Setting.slider("Высота прицела", 0.8, 0, 1))
                .add(Setting.slider("Задержка, мс", 0, 0, 500))
                .add(Setting.bool("Ждать кулдаун", true)));

        reg(Page.COMBAT, "Criticals", "Бьёт критами: ждёт падения и умеет сам подпрыгивать перед ударом")
                .add(Setting.bool("Автопрыжок", true));

        reg(Page.COMBAT, "Reach", "Увеличивает дистанцию взаимодействия с блоками и сущностями до 6 блоков");

        reg(Page.COMBAT, "Velocity", "Контроль отбрасывания: антиотбрасывание и отсутствие толкания")
                .add(Setting.slider("Горизонталь, %", 0, 0, 100))
                .add(Setting.slider("Вертикаль, %", 0, 0, 100))
                .add(Setting.bool("NoPush", true));

        reg(Page.COMBAT, "AutoClicker", "Быстрые клики атаки, пока зажата кнопка удара")
                .add(Setting.slider("CPS", 10, 1, 20));

        // ---------------- Movement ----------------
        reg(Page.MOVEMENT, "Sprint", "Бесконечный бег: бежишь, пока идёшь вперёд");
        reg(Page.MOVEMENT, "Speed", "Увеличивает скорость движения персонажа")
                .add(Setting.slider("Множитель", 1.5, 1, 4));
        reg(Page.MOVEMENT, "Fly", "Позволяет персонажу летать: пробел вверх, шифт вниз")
                .add(Setting.slider("Скорость", 0.6, 0.1, 3))
                .add(Setting.slider("Вертикаль", 0.4, 0.1, 2));
        reg(Page.MOVEMENT, "HighJump", "Прыжок становится гораздо выше")
                .add(Setting.slider("Множитель", 1.6, 1, 4));
        reg(Page.MOVEMENT, "Step", "Прохождение препятствий без прыжков")
                .add(Setting.slider("Высота", 1.0, 0.6, 2.5));
        reg(Page.MOVEMENT, "NoFall", "При падении с любой высоты урон не наносится");
        reg(Page.MOVEMENT, "Jesus", "Хождение по воде и лаве");
        reg(Page.MOVEMENT, "Spider", "Позволяет подниматься по стенам, как паук");
        reg(Page.MOVEMENT, "FastLadder", "Ускоренное перемещение по лестницам");
        reg(Page.MOVEMENT, "AirJump", "Прыжок в любой момент, в том числе в воздухе");
        reg(Page.MOVEMENT, "NoWeb", "В паутине и кустах двигаешься без замедления");
        reg(Page.MOVEMENT, "InventoryMove", "Можно ходить с открытым инвентарём");
        reg(Page.MOVEMENT, "AntiVoid", "Возвращает на безопасное место, если падаешь в бездну")
                .add(Setting.slider("Падение, блоков", 4, 2, 20));

        // ---------------- Player ----------------
        reg(Page.PLAYER, "Scaffold", "Ставит блоки под ногами во время ходьбы");
        reg(Page.PLAYER, "Nuker", "Разрушает блоки в зоне действия")
                .add(Setting.slider("Радиус", 3, 1, 5));
        reg(Page.PLAYER, "AutoArmor", "Автоматически надевает лучшую броню из инвентаря");
        reg(Page.PLAYER, "AutoEat", "Сам ест, когда голод опускается до порога")
                .add(Setting.slider("Голод", 14, 1, 19));
        reg(Page.PLAYER, "AutoTotem", "Кладёт тотем бессмертия во вторую руку")
                .add(Setting.slider("Здоровье", 8, 1, 19))
                .add(Setting.bool("Всегда", true));
        reg(Page.PLAYER, "AutoTool", "Выбирает лучший инструмент для разрушаемого блока");
        reg(Page.PLAYER, "AutoWalk", "Автоматическая ходьба вперёд");
        reg(Page.PLAYER, "AutoDisconnect", "Отключает от сервера при малом здоровье")
                .add(Setting.slider("Здоровье", 4, 1, 10));
        reg(Page.PLAYER, "ChestStealer", "Забирает все вещи из открытого сундука")
                .add(Setting.slider("Задержка, тиков", 2, 0, 10))
                .add(Setting.bool("Закрывать", true));

        // ---------------- ESP ----------------
        targets(reg(Page.ESP, "Entity ESP", "Обводка целей сквозь стены, как у эффекта свечения, цвет можно выбрать")
                .add(Setting.color("Цвет", 0.97))
                .add(Setting.slider("Дистанция", 64, 16, 128)));
        targets(reg(Page.ESP, "Tracers", "Линии от прицела до мобов, игроков и животных")
                .add(Setting.color("Цвет", 0.55))
                .add(Setting.slider("Дистанция", 64, 16, 128)));

        // ---------------- Render ----------------
        reg(Page.RENDER, "FullBright", "Максимальная яркость, как постоянное ночное зрение");
        reg(Page.RENDER, "No Rain", "Визуально отключает дождь");

        // ---------------- Display ----------------
        reg(Page.DISPLAY, "HUD", "Информационные плашки: ник, FPS, пинг, координаты и список модулей").on()
                .add(Setting.bool("Информация", true))
                .add(Setting.bool("Координаты", true))
                .add(Setting.bool("Список модулей", true));
        reg(Page.DISPLAY, "BetterCrosshair", "Свой прицел: размер, зазор, толщина и цвет")
                .add(Setting.color("Цвет", 0.33))
                .add(Setting.slider("Размер", 5, 1, 20))
                .add(Setting.slider("Зазор", 2, 0, 10))
                .add(Setting.slider("Толщина", 1, 1, 4))
                .add(Setting.bool("Скрыть ванильный", true));
    }

    private ModuleManager() {}

    public static List<Module> all() {
        return ALL;
    }

    public static List<Module> get(Page p) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.page == p) out.add(m);
        return out;
    }

    public static Module get(String name) {
        for (Module m : ALL) if (m.name.equals(name)) return m;
        return null;
    }

    public static boolean isEnabled(String name) {
        Module m = get(name);
        return m != null && m.enabled;
    }
}
