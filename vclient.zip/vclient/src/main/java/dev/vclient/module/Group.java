package dev.vclient.module;

public enum Group {
    COMBAT("Combat"),
    VISUALS("Visuals"),
    PLAYER("Player"),
    SETTINGS("Settings");

    public final String title;

    Group(String title) {
        this.title = title;
    }
}
