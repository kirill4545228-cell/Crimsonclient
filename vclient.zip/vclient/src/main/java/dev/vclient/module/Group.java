package dev.vclient.module;

public enum Group {
    COMBAT("Combat"),
    PLAYER("Player"),
    VISUALS("Visuals");

    public final String title;

    Group(String title) {
        this.title = title;
    }
}
