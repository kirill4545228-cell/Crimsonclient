package dev.vclient;

import dev.vclient.features.Aimbot;
import dev.vclient.features.BowAimbot;
import dev.vclient.features.KillAura;
import dev.vclient.features.LegitAura;
import dev.vclient.features.EspRenderer;
import dev.vclient.features.TriggerBot;
import dev.vclient.gui.ClickGuiScreen;
import dev.vclient.hud.Hud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class VClient implements ClientModInitializer {
    public static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.vclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.openScreen(new ClickGuiScreen());
                }
            }
            TriggerBot.tick(client);
            KillAura.tick(client);
            LegitAura.tick(client);
        });

        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            Aimbot.update(tickDelta);
            BowAimbot.update(tickDelta);
            LegitAura.update(tickDelta);
            Hud.render(matrices, tickDelta);
        });

        WorldRenderEvents.LAST.register(EspRenderer::render);
    }
}
