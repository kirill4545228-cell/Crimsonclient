package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.BowItem;
import net.minecraft.util.math.Vec3d;

/**
 * Расчёт баллистики лука (полный натяг): за тик позиция += скорость,
 * скорость *= 0.99, vy -= 0.05. Подбирает угол под дальность и
 * упреждает движение цели по времени полёта стрелы.
 */
public final class BowAimbot {
    private static final double SPEED = 3.0;
    private static long last = System.nanoTime();

    private BowAimbot() {}

    public static void update(float td) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        Module mod = ModuleManager.get("BowAimbot");
        if (mod == null || !mod.enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null || mc.currentScreen != null) return;

        if (!pl.isUsingItem() || !(pl.getActiveItem().getItem() instanceof BowItem)) {
            mod.status = pl.getMainHandStack().getItem() instanceof BowItem ? "натяни лук" : "нужен лук";
            return;
        }

        double range = mod.num("Дистанция");
        double fov = mod.num("FOV");
        boolean predict = mod.getBool("Предсказание");
        Vec3d eye = pl.getCameraPosVec(td);

        Entity target = null;
        double bestAng = fov / 2.0;
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(mod, e, pl)) continue;
            if (pl.distanceTo(e) > range) continue;
            Vec3d c = new Vec3d(e.getX(), e.getY() + e.getHeight() * 0.6, e.getZ());
            float[] r = Rot.to(eye, c);
            double ang = Rot.angDist(pl, r[0], r[1]);
            if (ang <= bestAng) { bestAng = ang; target = e; }
        }
        if (target == null) { mod.status = "нет цели"; return; }

        Vec3d start = new Vec3d(pl.getX(), pl.getEyeY() - 0.1, pl.getZ());
        Vec3d sv = pl.getVelocity();
        double svx = sv.x, svy = pl.isOnGround() ? 0 : sv.y, svz = sv.z;

        Vec3d center = new Vec3d(target.getX(), target.getY() + target.getHeight() * 0.6, target.getZ());
        double tvx = target.getX() - target.prevX;
        double tvy = target.isOnGround() ? 0 : target.getY() - target.prevY;
        double tvz = target.getZ() - target.prevZ;

        double ticks = 0;
        double[] sol = null;
        for (int it = 0; it < (predict ? 4 : 1); it++) {
            Vec3d tp = center.add(tvx * ticks, tvy * ticks, tvz * ticks);
            sol = solve(start, tp, svx, svy, svz);
            ticks = (predict && !Double.isNaN(sol[2])) ? sol[2] : 0;
        }

        Rot.approach(pl, (float) sol[0], (float) sol[1], Rot.factor(dt, mod.num("Скорость")));
        mod.status = target.getName().getString() + " " + String.format("%.0f", pl.distanceTo(target)) + "м"
                + (sol[3] > 0 ? "" : " (далеко)");
    }

    /** {yaw, pitch, ticks, found(1/0)} */
    private static double[] solve(Vec3d s, Vec3d tp, double svx, double svy, double svz) {
        double dx = tp.x - s.x, dz = tp.z - s.z;
        double D = Math.hypot(dx, dz);
        double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;

        double prevDiff = Double.NaN, prevA = 0;
        for (double a = -60; a <= 80; a += 1.0) {
            double[] sim = simulate(s, yaw, -a, D, svx, svy, svz);
            if (Double.isNaN(sim[0])) continue;
            double diff = sim[0] - tp.y;
            if (!Double.isNaN(prevDiff) && prevDiff < 0 && diff >= 0) {
                double lo = prevA, hi = a;
                double[] res = sim;
                for (int i = 0; i < 24; i++) {
                    double mid = (lo + hi) / 2;
                    double[] sm = simulate(s, yaw, -mid, D, svx, svy, svz);
                    if (Double.isNaN(sm[0]) || sm[0] - tp.y >= 0) { hi = mid; if (!Double.isNaN(sm[0])) res = sm; }
                    else lo = mid;
                }
                return new double[]{yaw, -hi, res[1], 1};
            }
            prevDiff = diff;
            prevA = a;
        }
        // цель вне досягаемости: целимся под максимальную дальность
        return new double[]{yaw, -40, Double.NaN, 0};
    }

    /** {высота стрелы на горизонтальной дистанции D, тиков до неё} или NaN. */
    private static double[] simulate(Vec3d s, double yawDeg, double pitchDeg, double D,
                                     double svx, double svy, double svz) {
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        double vx = -Math.sin(yaw) * Math.cos(pitch) * SPEED + svx;
        double vy = -Math.sin(pitch) * SPEED + svy;
        double vz = Math.cos(yaw) * Math.cos(pitch) * SPEED + svz;
        double px = s.x, py = s.y, pz = s.z, prevH = 0;
        for (int i = 1; i <= 200; i++) {
            double nx = px + vx, ny = py + vy, nz = pz + vz;
            double h = Math.hypot(nx - s.x, nz - s.z);
            if (h >= D) {
                double frac = (D - prevH) / Math.max(1e-9, h - prevH);
                return new double[]{py + (ny - py) * frac, i - 1 + frac};
            }
            px = nx; py = ny; pz = nz; prevH = h;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            vy -= 0.05;
            if (py < s.y - 150) break;
        }
        return new double[]{Double.NaN, Double.NaN};
    }
}
