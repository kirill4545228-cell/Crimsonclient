package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public final class TriggerBot {
    private static long lastHit = 0;

    private TriggerBot() {}

    /** Вызывается каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        Module mod = ModuleManager.get("Trigger Bot");
        if (mod == null || !mod.enabled) return;

        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult)) return;
        Entity e = ((EntityHitResult) hr).getEntity();
        if (!(e instanceof LivingEntity) || !e.isAlive()) return;
        if (mod.getBool("Только игроки") && !(e instanceof PlayerEntity)) return;
        if (pl.isUsingItem()) return;
        if (mod.getBool("Ждать кулдаун") && pl.getAttackCooldownProgress(0.5f) < 1f) return;

        long now = System.currentTimeMillis();
        if (now - lastHit < mod.num("Задержка, мс")) return;

        mc.interactionManager.attackEntity(pl, e);
        pl.swingHand(Hand.MAIN_HAND);
        lastHit = now;
    }
}
