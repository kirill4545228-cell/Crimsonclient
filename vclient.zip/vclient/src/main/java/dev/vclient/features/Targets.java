package dev.vclient.features;

import dev.vclient.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

/** Общий фильтр целей по настройкам «Игроки / Мобы / Животные». */
public final class Targets {
    private Targets() {}

    public static boolean valid(Module mod, Entity e, Entity self) {
        if (e == self || !(e instanceof LivingEntity) || !e.isAlive()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) {
            return !((PlayerEntity) e).isSpectator() && mod.getBool("Игроки");
        }
        if (e instanceof Monster) return mod.getBool("Мобы");
        return mod.getBool("Животные");
    }
}
