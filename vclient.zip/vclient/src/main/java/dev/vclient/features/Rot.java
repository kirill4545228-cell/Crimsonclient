package dev.vclient.features;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Rot {
    private Rot() {}

    /** {yaw, pitch} в градусах (формат Minecraft). */
    public static float[] to(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, pitch};
    }

    public static float factor(float dt, double speed) {
        return 1f - (float) Math.exp(-dt * speed * 1.5);
    }

    public static double angDist(ClientPlayerEntity pl, float yaw, float pitch) {
        return Math.hypot(MathHelper.wrapDegrees(yaw - pl.yaw), pitch - pl.pitch);
    }

    /** Плавно приближает взгляд игрока к (yaw, pitch). */
    public static void approach(ClientPlayerEntity pl, float yaw, float pitch, float f) {
        float dyaw = MathHelper.wrapDegrees(yaw - pl.yaw) * f;
        float np = MathHelper.clamp(pl.pitch + (pitch - pl.pitch) * f, -90f, 90f);
        float dp = np - pl.pitch;
        pl.yaw += dyaw;
        pl.prevYaw += dyaw;
        pl.pitch = np;
        pl.prevPitch += dp;
    }
}
