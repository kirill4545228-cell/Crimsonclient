package dev.vclient.features;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.vclient.gui.Ui;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public final class VisualFeatures {
    private static double oldGamma = -1;

    private VisualFeatures() {}

    /** Каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        if (ModuleManager.isEnabled("FullBright")) {
            if (oldGamma < 0) oldGamma = mc.options.gamma;
            mc.options.gamma = 16.0;
        } else if (oldGamma >= 0) {
            mc.options.gamma = oldGamma;
            oldGamma = -1;
        }
    }

    /** Каждый кадр, поверх HUD. */
    public static void renderHud(MatrixStack m, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        Module tr = ModuleManager.get("Tracers");
        if (tr != null && tr.enabled) tracers(m, td, mc, tr);

        Module ch = ModuleManager.get("BetterCrosshair");
        if (ch != null && ch.enabled) crosshair(m, mc, ch);
    }

    private static void crosshair(MatrixStack m, MinecraftClient mc, Module mod) {
        int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
        int size = (int) mod.num("Размер"), gap = (int) mod.num("Зазор"), th = (int) mod.num("Толщина");
        int col = 0xFF000000 | mod.color("Цвет");
        int y1 = cy - th / 2, x1 = cx - th / 2;
        Ui.fill(m, cx - gap - size, y1, cx - gap, y1 + th, col);
        Ui.fill(m, cx + gap, y1, cx + gap + size, y1 + th, col);
        Ui.fill(m, x1, cy - gap - size, x1 + th, cy - gap, col);
        Ui.fill(m, x1, cy + gap, x1 + th, cy + gap + size, col);
    }

    private static void tracers(MatrixStack m, float td, MinecraftClient mc, Module mod) {
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d cp = cam.getPos();
        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        double th = Math.tan(Math.toRadians(mc.options.fov) / 2.0);
        double aspect = (double) sw / sh;
        double maxD = mod.num("Дистанция");

        List<float[]> pts = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(mod, e, mc.player)) continue;
            if (mc.player.distanceTo(e) > maxD) continue;
            double x = MathHelper.lerp(td, e.prevX, e.getX()) - cp.x;
            double y = MathHelper.lerp(td, e.prevY, e.getY()) + e.getHeight() / 2.0 - cp.y;
            double z = MathHelper.lerp(td, e.prevZ, e.getZ()) - cp.z;
            double d = x * fx + y * fy + z * fz;
            if (d < 0.05) continue;
            double px = (x * rx + y * ry + z * rz) / (d * th * aspect);
            double py = (x * ux + y * uy + z * uz) / (d * th);
            pts.add(new float[]{(float) ((px * 0.5 + 0.5) * sw), (float) ((0.5 - py * 0.5) * sh)});
        }
        if (pts.isEmpty()) return;

        int rgb = mod.color("Цвет");
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;

        RenderSystem.disableDepthTest();
        RenderSystem.disableTexture();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(1.5f);
        Matrix4f mt = m.peek().getModel();
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        for (float[] p : pts) {
            bb.vertex(mt, sw / 2f, sh / 2f, 0f).color(r, g, b, 0.9f).next();
            bb.vertex(mt, p[0], p[1], 0f).color(r, g, b, 0.9f).next();
        }
        t.draw();
        RenderSystem.lineWidth(1f);
        RenderSystem.disableBlend();
        RenderSystem.enableTexture();
        RenderSystem.enableDepthTest();
    }
}
