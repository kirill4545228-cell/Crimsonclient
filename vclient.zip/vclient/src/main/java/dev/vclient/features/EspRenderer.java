package dev.vclient.features;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public final class EspRenderer {
    public static int count = 0;

    private EspRenderer() {}

    public static void render(WorldRenderContext ctx) {
        Module mod = ModuleManager.get("Entity ESP");
        if (mod == null || !mod.enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        count = 0;
        Vec3d cam = ctx.camera().getPos();
        MatrixStack ms = ctx.matrixStack();
        float td = ctx.tickDelta();

        int rgb = mod.color("Цвет");
        float r = ((rgb >> 16) & 255) / 255f;
        float g = ((rgb >> 8) & 255) / 255f;
        float b = (rgb & 255) / 255f;
        double maxDist = mod.num("Дистанция");
        boolean fill = mod.getBool("Заливка");

        List<Box> boxes = new ArrayList<>();
        for (Entity p : mc.world.getEntities()) {
            if (!Targets.valid(mod, p, mc.player)) continue;
            if (mc.player.distanceTo(p) > maxDist) continue;
            double x = MathHelper.lerp(td, p.prevX, p.getX());
            double y = MathHelper.lerp(td, p.prevY, p.getY());
            double z = MathHelper.lerp(td, p.prevZ, p.getZ());
            Box box = p.getBoundingBox()
                    .offset(x - p.getX(), y - p.getY(), z - p.getZ())
                    .offset(-cam.x, -cam.y, -cam.z)
                    .expand(0.02);
            boxes.add(box);
        }
        count = boxes.size();
        if (boxes.isEmpty()) return;

        RenderSystem.disableDepthTest();
        RenderSystem.disableTexture();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableFog();
        RenderSystem.lineWidth(2f);

        Matrix4f mt = ms.peek().getModel();
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();

        if (fill) {
            bb.begin(GL11.GL_QUADS, VertexFormats.POSITION_COLOR);
            for (Box bx : boxes) quads(bb, mt, bx, r, g, b, 0.22f);
            t.draw();
        }

        bb.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        for (Box bx : boxes) lines(bb, mt, bx, r, g, b, 1f);
        t.draw();

        RenderSystem.lineWidth(1f);
        RenderSystem.enableFog();
        RenderSystem.disableBlend();
        RenderSystem.enableTexture();
        RenderSystem.enableDepthTest();
    }

    private static void v(BufferBuilder bb, Matrix4f mt, double x, double y, double z, float r, float g, float b, float a) {
        bb.vertex(mt, (float) x, (float) y, (float) z).color(r, g, b, a).next();
    }

    private static void line(BufferBuilder bb, Matrix4f mt, double x1, double y1, double z1,
                             double x2, double y2, double z2, float r, float g, float b, float a) {
        v(bb, mt, x1, y1, z1, r, g, b, a);
        v(bb, mt, x2, y2, z2, r, g, b, a);
    }

    private static void lines(BufferBuilder bb, Matrix4f mt, Box q, float r, float g, float b, float a) {
        double x1 = q.minX, y1 = q.minY, z1 = q.minZ, x2 = q.maxX, y2 = q.maxY, z2 = q.maxZ;
        // низ
        line(bb, mt, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(bb, mt, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(bb, mt, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(bb, mt, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // верх
        line(bb, mt, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(bb, mt, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(bb, mt, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(bb, mt, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // стойки
        line(bb, mt, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(bb, mt, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(bb, mt, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(bb, mt, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void quads(BufferBuilder bb, Matrix4f mt, Box q, float r, float g, float b, float a) {
        double x1 = q.minX, y1 = q.minY, z1 = q.minZ, x2 = q.maxX, y2 = q.maxY, z2 = q.maxZ;
        // низ / верх
        v(bb, mt, x1, y1, z1, r, g, b, a); v(bb, mt, x2, y1, z1, r, g, b, a); v(bb, mt, x2, y1, z2, r, g, b, a); v(bb, mt, x1, y1, z2, r, g, b, a);
        v(bb, mt, x1, y2, z1, r, g, b, a); v(bb, mt, x1, y2, z2, r, g, b, a); v(bb, mt, x2, y2, z2, r, g, b, a); v(bb, mt, x2, y2, z1, r, g, b, a);
        // север / юг
        v(bb, mt, x1, y1, z1, r, g, b, a); v(bb, mt, x1, y2, z1, r, g, b, a); v(bb, mt, x2, y2, z1, r, g, b, a); v(bb, mt, x2, y1, z1, r, g, b, a);
        v(bb, mt, x1, y1, z2, r, g, b, a); v(bb, mt, x2, y1, z2, r, g, b, a); v(bb, mt, x2, y2, z2, r, g, b, a); v(bb, mt, x1, y2, z2, r, g, b, a);
        // запад / восток
        v(bb, mt, x1, y1, z1, r, g, b, a); v(bb, mt, x1, y1, z2, r, g, b, a); v(bb, mt, x1, y2, z2, r, g, b, a); v(bb, mt, x1, y2, z1, r, g, b, a);
        v(bb, mt, x2, y1, z1, r, g, b, a); v(bb, mt, x2, y2, z1, r, g, b, a); v(bb, mt, x2, y2, z2, r, g, b, a); v(bb, mt, x2, y1, z2, r, g, b, a);
    }
}
