package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public final class MoveFeatures {
    private static boolean prevGround = false, stepWas = false, haveSafe = false;
    private static int airCd = 0;
    private static double sx, sy, sz;

    private MoveFeatures() {}

    private static Module m(String n) {
        Module x = ModuleManager.get(n);
        return x != null && x.enabled ? x : null;
    }

    private static void horizontal(ClientPlayerEntity pl, double sp) {
        double f = pl.input.movementForward, s = pl.input.movementSideways;
        double yaw = Math.toRadians(pl.yaw);
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double l = Math.sqrt(dx * dx + dz * dz);
        if (l < 1e-4) return;
        Vec3d v = pl.getVelocity();
        pl.setVelocity(dx / l * sp, v.y, dz / l * sp);
    }

    /** Каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null) return;
        Module mod;
        boolean moving = pl.input.movementForward != 0 || pl.input.movementSideways != 0;

        // Sprint
        if (m("Sprint") != null && pl.input.movementForward > 0 && !pl.isSneaking()
                && pl.getHungerManager().getFoodLevel() > 6 && !pl.horizontalCollision) {
            pl.setSprinting(true);
        }

        // Speed
        if ((mod = m("Speed")) != null && moving && !pl.isSneaking()) {
            horizontal(pl, 0.2873 * mod.num("Множитель"));
        }

        // Fly
        if ((mod = m("Fly")) != null) {
            double h = mod.num("Скорость"), vv = mod.num("Вертикаль");
            double yv = pl.input.jumping ? vv : (pl.input.sneaking ? -vv : 0);
            if (moving) {
                horizontal(pl, h);
                Vec3d v = pl.getVelocity();
                pl.setVelocity(v.x, yv, v.z);
            } else {
                pl.setVelocity(0, yv, 0);
            }
            pl.fallDistance = 0f;
        }

        // HighJump
        if ((mod = m("HighJump")) != null && prevGround && !pl.isOnGround()) {
            Vec3d v = pl.getVelocity();
            if (v.y > 0.2) pl.setVelocity(v.x, v.y * mod.num("Множитель"), v.z);
        }

        // Step
        if ((mod = m("Step")) != null) {
            pl.stepHeight = (float) mod.num("Высота");
            stepWas = true;
        } else if (stepWas) {
            pl.stepHeight = 0.6f;
            stepWas = false;
        }

        // NoFall
        if (m("NoFall") != null && pl.fallDistance > 2.5f && !pl.abilities.flying) {
            pl.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
        }

        // Jesus
        if (m("Jesus") != null && !pl.isSneaking()) {
            boolean inFluid = !mc.world.getFluidState(pl.getBlockPos()).isEmpty();
            boolean below = !mc.world.getFluidState(new BlockPos(pl.getX(), pl.getY() - 0.05, pl.getZ())).isEmpty();
            Vec3d v = pl.getVelocity();
            if (inFluid) {
                pl.setVelocity(v.x, Math.max(v.y, 0.15), v.z);
            } else if (below && v.y <= 0) {
                pl.setVelocity(v.x, 0, v.z);
                pl.setOnGround(true);
                pl.fallDistance = 0f;
            }
        }

        // Spider
        if (m("Spider") != null && pl.horizontalCollision && !pl.isSneaking()) {
            Vec3d v = pl.getVelocity();
            pl.setVelocity(v.x, 0.2, v.z);
        }

        // FastLadder
        if (m("FastLadder") != null && pl.isClimbing() && pl.horizontalCollision && pl.input.movementForward > 0) {
            Vec3d v = pl.getVelocity();
            pl.setVelocity(v.x, 0.35, v.z);
        }

        // AirJump
        if (airCd > 0) airCd--;
        if (m("AirJump") != null && pl.input.jumping && !pl.isOnGround() && airCd == 0
                && !pl.isClimbing() && !pl.isTouchingWater()) {
            Vec3d v = pl.getVelocity();
            pl.setVelocity(v.x, 0.42, v.z);
            airCd = 6;
        }

        // InventoryMove
        if (m("InventoryMove") != null && mc.currentScreen instanceof HandledScreen) {
            long handle = mc.getWindow().getHandle();
            KeyBinding[] keys = {mc.options.keyForward, mc.options.keyBack, mc.options.keyLeft,
                    mc.options.keyRight, mc.options.keyJump, mc.options.keySprint};
            for (KeyBinding k : keys) {
                k.setPressed(InputUtil.isKeyPressed(handle, KeyBindingHelper.getBoundKeyOf(k).getCode()));
            }
        }

        // AntiVoid
        if ((mod = m("AntiVoid")) != null) {
            if (pl.isOnGround()) {
                sx = pl.getX(); sy = pl.getY(); sz = pl.getZ();
                haveSafe = true;
            } else if (haveSafe && pl.getY() < 4 && pl.fallDistance > mod.num("Падение, блоков")) {
                pl.updatePosition(sx, sy, sz);
                pl.setVelocity(0, 0, 0);
                pl.fallDistance = 0f;
            }
        }

        prevGround = pl.isOnGround();
    }
}
