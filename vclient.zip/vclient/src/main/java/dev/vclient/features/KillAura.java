package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;

public final class KillAura {
    private static long lastHit = 0;
    private static int hits = 0;

    private KillAura() {}

    /** Каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        Module mod = ModuleManager.get("KillAura");
        if (mod == null || !mod.enabled) return;

        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) { mod.status = "закрой меню"; return; }

        double range = mod.num("Дистанция");
        boolean walls = mod.getBool("Через стены");

        Entity best = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(mod, e, pl)) continue;
            double d = pl.distanceTo(e);
            if (d > range) continue;
            if (!walls && !pl.canSee(e)) continue;
            if (d < bestD) { bestD = d; best = e; }
        }
        if (best == null) { mod.status = "нет целей | ударов: " + hits; return; }

        if (mod.getBool("Ждать кулдаун") && pl.getAttackCooldownProgress(0.5f) < 1f) {
            mod.status = best.getName().getString() + " (кулдаун)";
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastHit < mod.num("Задержка, мс")) return;

        mc.interactionManager.attackEntity(pl, best);
        pl.swingHand(Hand.MAIN_HAND);
        lastHit = now;
        hits++;
        mod.status = best.getName().getString() + " | ударов: " + hits;
    }
}
