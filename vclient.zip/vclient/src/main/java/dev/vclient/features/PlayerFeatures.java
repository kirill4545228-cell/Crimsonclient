package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.Entity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class PlayerFeatures {
    private static int armorCd = 0, totemCd = 0, stealCd = 0, stealTicks = 0, clickCd = 0, eatTicks = 0;
    private static boolean eating = false, walkWas = false;
    private static int prevSlot = -1;

    private PlayerFeatures() {}

    private static Module m(String n) {
        Module x = ModuleManager.get(n);
        return x != null && x.enabled ? x : null;
    }

    private static int containerSlot(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    /** Каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null || mc.interactionManager == null) return;
        Module mod;

        // AutoWalk
        if (m("AutoWalk") != null) {
            mc.options.keyForward.setPressed(true);
            walkWas = true;
        } else if (walkWas) {
            mc.options.keyForward.setPressed(false);
            walkWas = false;
        }

        // AutoDisconnect
        if ((mod = m("AutoDisconnect")) != null && !mc.isInSingleplayer()
                && pl.getHealth() > 0 && pl.getHealth() <= mod.num("Здоровье")) {
            pl.networkHandler.getConnection().disconnect(new LiteralText("[VClient] AutoDisconnect: HP " + (int) pl.getHealth()));
            return;
        }

        if (m("AutoArmor") != null) autoArmor(mc, pl);
        if ((mod = m("AutoTotem")) != null) autoTotem(mc, pl, mod);
        if ((mod = m("AutoEat")) != null) autoEat(mc, pl, mod);
        else if (eating) stopEating(mc, pl);
        if (m("AutoTool") != null) autoTool(mc, pl);
        if ((mod = m("AutoClicker")) != null) autoClicker(mc, pl, mod);
        if ((mod = m("ChestStealer")) != null) chestStealer(mc, pl, mod);
        else stealTicks = 0;
        if ((mod = m("Nuker")) != null) nuker(mc, pl, mod);
        if (m("Scaffold") != null) scaffold(mc, pl);
    }

    // ---------------- AutoArmor ----------------
    private static double armorScore(ItemStack st, EquipmentSlot type) {
        if (st.isEmpty()) return 0;
        if (!(st.getItem() instanceof ArmorItem)) return -1;
        ArmorItem a = (ArmorItem) st.getItem();
        if (a.getSlotType() != type) return -1;
        return a.getProtection() + a.getMaterial().getToughness() * 0.1;
    }

    private static void autoArmor(MinecraftClient mc, ClientPlayerEntity pl) {
        if (armorCd > 0) { armorCd--; return; }
        EquipmentSlot[] types = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int i = 0; i < 4; i++) {
            ItemStack cur = pl.inventory.getArmorStack(3 - i);
            if (!cur.isEmpty() && !(cur.getItem() instanceof ArmorItem)) continue; // например элитры
            double curScore = armorScore(cur, types[i]);
            int best = -1;
            double bestScore = curScore;
            for (int s = 0; s < 36; s++) {
                double sc = armorScore(pl.inventory.getStack(s), types[i]);
                if (sc > bestScore && !pl.inventory.getStack(s).isEmpty()) { bestScore = sc; best = s; }
            }
            if (best < 0) continue;
            if (!cur.isEmpty()) {
                mc.interactionManager.clickSlot(0, 5 + i, 0, SlotActionType.QUICK_MOVE, pl);
            } else {
                mc.interactionManager.clickSlot(0, containerSlot(best), 0, SlotActionType.QUICK_MOVE, pl);
            }
            armorCd = 3;
            return;
        }
    }

    // ---------------- AutoTotem ----------------
    private static void autoTotem(MinecraftClient mc, ClientPlayerEntity pl, Module mod) {
        if (totemCd > 0) { totemCd--; return; }
        if (pl.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) return;
        if (!mod.getBool("Всегда") && pl.getHealth() + pl.getAbsorptionAmount() > mod.num("Здоровье")) return;
        for (int s = 0; s < 36; s++) {
            if (pl.inventory.getStack(s).getItem() == Items.TOTEM_OF_UNDYING) {
                mc.interactionManager.clickSlot(0, containerSlot(s), 40, SlotActionType.SWAP, pl);
                totemCd = 4;
                return;
            }
        }
    }

    // ---------------- AutoEat ----------------
    private static int findFood(ClientPlayerEntity pl) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = pl.inventory.getStack(i);
            if (st.isEmpty() || !st.getItem().isFood()) continue;
            FoodComponent f = st.getItem().getFoodComponent();
            if (f != null && f.getStatusEffects().isEmpty()) return i;
        }
        return -1;
    }

    private static void stopEating(MinecraftClient mc, ClientPlayerEntity pl) {
        mc.options.keyUse.setPressed(false);
        if (prevSlot >= 0) pl.inventory.selectedSlot = prevSlot;
        prevSlot = -1;
        eating = false;
    }

    private static void autoEat(MinecraftClient mc, ClientPlayerEntity pl, Module mod) {
        int food = pl.getHungerManager().getFoodLevel();
        if (!eating) {
            if (food <= mod.num("Голод") && mc.currentScreen == null) {
                int slot = findFood(pl);
                if (slot >= 0) {
                    prevSlot = pl.inventory.selectedSlot;
                    pl.inventory.selectedSlot = slot;
                    mc.options.keyUse.setPressed(true);
                    eating = true;
                    eatTicks = 0;
                }
            }
        } else {
            eatTicks++;
            if (food >= 20 || (!pl.isUsingItem() && eatTicks > 5) || eatTicks > 80) stopEating(mc, pl);
        }
    }

    // ---------------- AutoTool ----------------
    private static void autoTool(MinecraftClient mc, ClientPlayerEntity pl) {
        if (!mc.options.keyAttack.isPressed() || mc.currentScreen != null) return;
        HitResult hr = mc.crosshairTarget;
        if (hr == null || hr.getType() != HitResult.Type.BLOCK) return;
        BlockState st = mc.world.getBlockState(((BlockHitResult) hr).getBlockPos());
        int best = pl.inventory.selectedSlot;
        float bs = pl.inventory.getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float s = pl.inventory.getStack(i).getMiningSpeedMultiplier(st);
            if (s > bs + 0.01f) { bs = s; best = i; }
        }
        pl.inventory.selectedSlot = best;
    }

    // ---------------- AutoClicker ----------------
    private static void autoClicker(MinecraftClient mc, ClientPlayerEntity pl, Module mod) {
        if (clickCd > 0) { clickCd--; return; }
        if (!mc.options.keyAttack.isPressed() || mc.currentScreen != null) return;
        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult)) return;
        Entity e = ((EntityHitResult) hr).getEntity();
        mc.interactionManager.attackEntity(pl, e);
        pl.swingHand(Hand.MAIN_HAND);
        clickCd = Math.max(0, Math.round(20f / (float) mod.num("CPS")) - 1);
    }

    // ---------------- ChestStealer ----------------
    private static void chestStealer(MinecraftClient mc, ClientPlayerEntity pl, Module mod) {
        if (!(mc.currentScreen instanceof GenericContainerScreen)) { stealTicks = 0; return; }
        if (stealCd > 0) { stealCd--; return; }
        GenericContainerScreenHandler h = ((GenericContainerScreen) mc.currentScreen).getScreenHandler();
        int n = h.getRows() * 9;
        stealTicks++;
        if (stealTicks < 400) {
            for (int i = 0; i < n; i++) {
                if (!h.getSlot(i).getStack().isEmpty()) {
                    mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, pl);
                    stealCd = (int) mod.num("Задержка, тиков");
                    return;
                }
            }
        }
        if (mod.getBool("Закрывать")) pl.closeHandledScreen();
    }

    // ---------------- Nuker ----------------
    private static void nuker(MinecraftClient mc, ClientPlayerEntity pl, Module mod) {
        if (mc.currentScreen != null) return;
        int r = (int) mod.num("Радиус");
        BlockPos base = pl.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    BlockPos p = base.add(x, y, z);
                    BlockState st = mc.world.getBlockState(p);
                    if (st.isAir() || !st.getFluidState().isEmpty()) continue;
                    if (st.getHardness(mc.world, p) < 0) continue;
                    double d = pl.squaredDistanceTo(Vec3d.ofCenter(p));
                    if (d > r * r) continue;
                    if (d < bd) { bd = d; best = p; }
                }
            }
        }
        if (best != null) {
            mc.interactionManager.updateBlockBreakingProgress(best, Direction.UP);
            pl.swingHand(Hand.MAIN_HAND);
        }
    }

    // ---------------- Scaffold ----------------
    private static void scaffold(MinecraftClient mc, ClientPlayerEntity pl) {
        if (mc.currentScreen != null || !(pl.getMainHandStack().getItem() instanceof BlockItem)) return;
        BlockPos below = new BlockPos(pl.getX(), pl.getY() - 1, pl.getZ());
        if (!mc.world.getBlockState(below).getMaterial().isReplaceable()) return;
        for (Direction d : Direction.values()) {
            BlockPos nb = below.offset(d);
            if (mc.world.getBlockState(nb).getMaterial().isReplaceable()) continue;
            Direction side = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(nb).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
            mc.interactionManager.interactBlock(pl, mc.world, Hand.MAIN_HAND, new BlockHitResult(hit, side, nb, false));
            pl.swingHand(Hand.MAIN_HAND);
            return;
        }
    }
}
