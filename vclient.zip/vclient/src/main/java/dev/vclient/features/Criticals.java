package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Криты: атакующие модули зовут ok() и ждут падения; при желании модуль сам подпрыгивает. */
public final class Criticals {
    private static boolean want = false;

    private Criticals() {}

    public static boolean ok(ClientPlayerEntity pl) {
        Module m = ModuleManager.get("Criticals");
        if (m == null || !m.enabled) return true;
        boolean crit = pl.fallDistance > 0.0f && !pl.isOnGround() && !pl.isClimbing()
                && !pl.isTouchingWater() && !pl.hasVehicle();
        if (!crit) want = true;
        return crit;
    }

    /** Каждый тик, после атакующих модулей. */
    public static void tick(MinecraftClient mc) {
        Module m = ModuleManager.get("Criticals");
        ClientPlayerEntity pl = mc.player;
        if (m != null && m.enabled && pl != null && want && m.getBool("Автопрыжок") && pl.isOnGround()) {
            Vec3d v = pl.getVelocity();
            pl.setVelocity(v.x, 0.42, v.z);
        }
        want = false;
    }
}
