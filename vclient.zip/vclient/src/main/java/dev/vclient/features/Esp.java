package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

/** ESP = ванильная обводка «свечения» (видна сквозь стены), цвет задаётся в меню. */
public final class Esp {
    public static int count = 0;

    private Esp() {}

    public static boolean applies(Entity e) {
        if (e == null || e.world == null || !e.world.isClient) return false;
        Module m = ModuleManager.get("Entity ESP");
        if (m == null || !m.enabled) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return false;
        if (!Targets.valid(m, e, mc.player)) return false;
        return mc.player.distanceTo(e) <= m.num("Дистанция");
    }

    public static int color() {
        Module m = ModuleManager.get("Entity ESP");
        return m == null ? 0xFFFFFF : m.color("Цвет");
    }

    public static void tick(MinecraftClient mc) {
        count = 0;
        Module m = ModuleManager.get("Entity ESP");
        if (m == null || !m.enabled || mc.world == null || mc.player == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (applies(e)) count++;
        }
    }
}
