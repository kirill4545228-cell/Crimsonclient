package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public final class LegitAura {
    private static final Random RND = new Random();
    private static Entity target;
    private static long last = System.nanoTime();
    private static long lastHit = 0;
    private static long nextJitter = 0;
    private static float jitYaw = 0, jitPitch = 0;
    private static int hits = 0;

    private LegitAura() {}

    private static boolean ok(Module mod, ClientPlayerEntity pl, Entity e, double range) {
        return Targets.valid(mod, e, pl) && pl.distanceTo(e) <= range && pl.canSee(e);
    }

    /** Каждый кадр: плавная доводка до цели. */
    public static void update(float td) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        Module mod = ModuleManager.get("LegitAura");
        if (mod == null || !mod.enabled) { target = null; return; }

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null) return;
        if (mc.currentScreen != null) { mod.status = "закрой меню"; return; }

        double range = mod.num("Дистанция");
        double fov = mod.num("FOV");
        double hFrac = mod.num("Высота прицела");
        Vec3d eye = pl.getCameraPosVec(td);

        if (target != null && !ok(mod, pl, target, range)) target = null;
        if (target == null) {
            double bestAng = fov / 2.0;
            for (Entity e : mc.world.getEntities()) {
                if (!ok(mod, pl, e, range)) continue;
                Vec3d p = new Vec3d(e.getX(), e.getY() + e.getHeight() * hFrac, e.getZ());
                float[] r = Rot.to(eye, p);
                double ang = Rot.angDist(pl, r[0], r[1]);
                if (ang <= bestAng) { bestAng = ang; target = e; }
            }
        }
        if (target == null) { mod.status = "нет цели | ударов: " + hits; return; }

        // небольшая случайная «дрожь», чтобы наводка выглядела живее
        long ms = System.currentTimeMillis();
        double jit = mod.num("Рандомизация");
        if (ms >= nextJitter) {
            jitYaw = (float) ((RND.nextDouble() - 0.5) * 2 * jit);
            jitPitch = (float) ((RND.nextDouble() - 0.5) * 2 * jit);
            nextJitter = ms + 120 + RND.nextInt(180);
        }

        Vec3d aim = new Vec3d(target.getX(), target.getY() + target.getHeight() * hFrac, target.getZ());
        float[] r = Rot.to(eye, aim);
        Rot.approach(pl, r[0] + jitYaw, r[1] + jitPitch, Rot.factor(dt, mod.num("Скорость")));
        mod.status = target.getName().getString() + " | ударов: " + hits;
    }

    /** Каждый тик: бьём, когда прицел реально на цели. */
    public static void tick(MinecraftClient mc) {
        Module mod = ModuleManager.get("LegitAura");
        if (mod == null || !mod.enabled) return;
        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult)) return;
        Entity e = ((EntityHitResult) hr).getEntity();
        if (!Targets.valid(mod, e, pl)) return;
        if (pl.isUsingItem()) return;
        if (mod.getBool("Ждать кулдаун") && pl.getAttackCooldownProgress(0.5f) < 1f) return;

        long now = System.currentTimeMillis();
        if (now - lastHit < mod.num("Задержка, мс")) return;

        mc.interactionManager.attackEntity(pl, e);
        pl.swingHand(Hand.MAIN_HAND);
        lastHit = now;
        hits++;
    }
}
