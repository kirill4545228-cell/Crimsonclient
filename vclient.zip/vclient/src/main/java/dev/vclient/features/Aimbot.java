package dev.vclient.features;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Aimbot {
    private static long last = System.nanoTime();

    private Aimbot() {}

    /** Вызывается каждый кадр. */
    public static void update(float tickDelta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        Module mod = ModuleManager.get("Aimbot");
        if (mod == null || !mod.enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity pl = mc.player;
        if (pl == null || mc.world == null || mc.currentScreen != null) return;
        if (mod.getBool("Только при ЛКМ") && !mc.options.keyAttack.isPressed()) return;

        double range = mod.num("Дистанция");
        double fov = mod.num("FOV");
        Vec3d eye = pl.getCameraPosVec(tickDelta);

        PlayerEntity best = null;
        Vec3d bestHead = null;
        double bestAng = fov / 2.0;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == pl || !p.isAlive() || p.isSpectator()) continue;
            if (pl.distanceTo(p) > range) continue;
            Vec3d head = new Vec3d(p.getX(), p.getEyeY(), p.getZ());
            float[] rot = rotations(eye, head);
            double ang = Math.hypot(MathHelper.wrapDegrees(rot[0] - pl.yaw), rot[1] - pl.pitch);
            if (ang <= bestAng) {
                bestAng = ang;
                best = p;
                bestHead = head;
            }
        }
        if (best == null) return;

        float[] rot = rotations(eye, bestHead);
        float f = 1f - (float) Math.exp(-dt * mod.num("Скорость") * 1.5);
        float dyaw = MathHelper.wrapDegrees(rot[0] - pl.yaw) * f;
        float newPitch = MathHelper.clamp(pl.pitch + (rot[1] - pl.pitch) * f, -90f, 90f);
        float dpitch = newPitch - pl.pitch;

        pl.yaw += dyaw;
        pl.prevYaw += dyaw;
        pl.pitch = newPitch;
        pl.prevPitch += dpitch;
    }

    private static float[] rotations(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, pitch};
    }
}
