package dev.vclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;

public final class Ui {
    public static final int[] ACCENTS = {0xFF4C7DFF, 0xFF9B6BFF, 0xFFFF4D6D, 0xFF3DDC97};
    public static int accentIdx = 0;

    public static final int PANEL = 0xFF131822;
    public static final int PANEL_BORDER = 0xFF232A3A;
    public static final int CARD = 0xFF1A2030;
    public static final int CARD_HOVER = 0xFF1F2638;
    public static final int CARD_BORDER = 0xFF262E42;
    public static final int SIDE_SEL = 0xFF222A3D;
    public static final int TEXT = 0xFFF2F4F8;
    public static final int MUTED = 0xFF7F8799;
    public static final int DIM = 0xFF4A5166;
    public static final int OFF_TRACK = 0xFF2E3548;
    public static final int OFF_KNOB = 0xFF9AA1B2;

    private Ui() {}

    public static int accent() {
        return ACCENTS[accentIdx % ACCENTS.length];
    }

    // ---------- primitives ----------
    public static void fill(MatrixStack m, int x1, int y1, int x2, int y2, int c) {
        DrawableHelper.fill(m, x1, y1, x2, y2, c);
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        int in = 0;
        while (in < r) {
            double dx = r - in - 0.5;
            if (dx * dx + dy * dy <= r * r) break;
            in++;
        }
        return in;
    }

    public static void rrect(MatrixStack m, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            fill(m, x, y, x + w, y + h, c);
            return;
        }
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            fill(m, x + in, y + i, x + w - in, y + i + 1, c);
            fill(m, x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
        fill(m, x, y + r, x + w, y + h - r, c);
    }

    /** Rounded box with 1px border (use opaque colors). */
    public static void rbox(MatrixStack m, int x, int y, int w, int h, int r, int fillC, int borderC) {
        rrect(m, x, y, w, h, r, borderC);
        rrect(m, x + 1, y + 1, w - 2, h - 2, Math.max(1, r - 1), fillC);
    }

    // ---------- text ----------
    public static void text(MatrixStack m, String s, float x, float y, int c) {
        MinecraftClient.getInstance().textRenderer.draw(m, s, x, y, c);
    }

    public static void textScaled(MatrixStack m, String s, float x, float y, int c, float scale) {
        m.push();
        m.translate(x, y, 0);
        m.scale(scale, scale, 1f);
        MinecraftClient.getInstance().textRenderer.draw(m, s, 0, 0, c);
        m.pop();
    }

    public static int width(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    public static float widthScaled(String s, float scale) {
        return width(s) * scale;
    }

    public static List<String> wrap(String s, int maxW, float scale) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            String t = cur.length() == 0 ? w : cur.toString() + " " + w;
            if (cur.length() == 0 || widthScaled(t, scale) <= maxW) {
                cur.setLength(0);
                cur.append(t);
            } else {
                out.add(cur.toString());
                cur.setLength(0);
                cur.append(w);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ---------- widgets ----------
    public static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Toggle switch 18x10. t = 0..1 animation. */
    public static void toggle(MatrixStack m, int x, int y, float t) {
        rrect(m, x, y, 18, 10, 5, lerpColor(OFF_TRACK, accent(), t));
        int kx = x + 2 + Math.round(8 * t);
        rrect(m, kx, y + 2, 6, 6, 3, lerpColor(OFF_KNOB, 0xFFFFFFFF, t));
    }
}
