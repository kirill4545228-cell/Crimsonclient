package dev.vclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.DrawableHelper;

public final class Ui {
    public static final int ACCENT = 0xFFFF1A5E;
    public static final int ACCENT_GLOW = 0x40FF1A5E;
    public static final int PANEL = 0xF2100409;
    public static final int CARD = 0xE61A0A10;
    public static final int CARD_HOVER = 0xE62A1018;
    public static final int LINE = 0xFF3A0B1A;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int GRAY = 0xFFAAAAAA;
    public static final int BADGE = 0xFF2A2A2E;

    private Ui() {}

    public static void fill(MatrixStack m, int x1, int y1, int x2, int y2, int c) {
        DrawableHelper.fill(m, x1, y1, x2, y2, c);
    }

    public static void outline(MatrixStack m, int x, int y, int w, int h, int c) {
        fill(m, x, y, x + w, y + 1, c);
        fill(m, x, y + h - 1, x + w, y + h, c);
        fill(m, x, y, x + 1, y + h, c);
        fill(m, x + w - 1, y, x + w, y + h, c);
    }

    public static void text(MatrixStack m, String s, float x, float y, int c) {
        MinecraftClient.getInstance().textRenderer.drawWithShadow(m, s, x, y, c);
    }

    public static void textScaled(MatrixStack m, String s, float x, float y, int c, float scale) {
        m.push();
        m.translate(x, y, 0);
        m.scale(scale, scale, 1f);
        MinecraftClient.getInstance().textRenderer.drawWithShadow(m, s, 0, 0, c);
        m.pop();
    }

    public static int width(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Box with glow + accent border. */
    public static void glowBox(MatrixStack m, int x, int y, int w, int h, int bg, int border) {
        outline(m, x - 1, y - 1, w + 2, h + 2, ACCENT_GLOW);
        fill(m, x, y, x + w, y + h, bg);
        outline(m, x, y, w, h, border);
    }

    public static void checkbox(MatrixStack m, int x, int y, boolean on) {
        fill(m, x, y, x + 8, y + 8, on ? ACCENT : 0xFF222024);
        outline(m, x, y, 8, 8, on ? ACCENT : 0xFF55505A);
        if (on) {
            fill(m, x + 2, y + 4, x + 3, y + 5, WHITE);
            fill(m, x + 3, y + 5, x + 4, y + 6, WHITE);
            fill(m, x + 4, y + 4, x + 5, y + 5, WHITE);
            fill(m, x + 5, y + 3, x + 6, y + 4, WHITE);
            fill(m, x + 6, y + 2, x + 7, y + 3, WHITE);
        }
    }
}
