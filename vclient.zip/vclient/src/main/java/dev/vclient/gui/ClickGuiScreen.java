package dev.vclient.gui;

import dev.vclient.module.Group;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import dev.vclient.module.Page;
import dev.vclient.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
    private static final int PW = 420, PH = 250, SB = 104, TOP = 24, GAP = 6;

    private static Page page = Page.COMBAT;
    private static double scroll = 0;
    private static int filter = 0; // 0 все, 1 включённые, 2 выключенные
    private static boolean dim = true;
    private static final boolean[] collapsed = new boolean[Group.values().length];

    private double maxScroll = 0;
    private boolean searching = false;
    private String query = "";
    private int px, py;
    private long lastNs = System.nanoTime();
    private Setting dragging;
    private int dragX0, dragX1;

    private static class Card {
        Module m;
        int x, y, w, h, headH;
        List<String> lines;
    }

    private static class Side {
        Group g;
        Page p; // null = group header
        int y;
    }

    public ClickGuiScreen() {
        super(new LiteralText("VClient"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;
    }

    // ---------- geometry ----------
    private int vx() { return px + SB + 8; }
    private int vy() { return py + TOP + 6; }
    private int vw() { return PW - SB - 18; }
    private int vh() { return PH - TOP - 10; }

    private static int rowH(Setting s) {
        return s.slider ? 22 : 14;
    }

    private List<Module> source() {
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<Module> base = q.isEmpty() ? ModuleManager.get(page) : ModuleManager.all();
        List<Module> out = new ArrayList<>();
        for (Module m : base) {
            if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)
                    && !m.desc.toLowerCase(Locale.ROOT).contains(q)) continue;
            if (filter == 1 && !m.enabled) continue;
            if (filter == 2 && m.enabled) continue;
            out.add(m);
        }
        return out;
    }

    private List<Card> layout() {
        List<Card> out = new ArrayList<>();
        int cw = (vw() - GAP) / 2;
        int[] colY = {0, 0};
        for (Module m : source()) {
            Card c = new Card();
            c.m = m;
            c.w = cw;
            c.lines = Ui.wrap(m.desc, cw - 16, 0.8f);
            c.headH = 7 + 11 + c.lines.size() * 8 + 6;
            c.h = c.headH;
            if (m.expanded && !m.settings.isEmpty()) {
                c.h += 6;
                for (Setting s : m.settings) c.h += rowH(s);
            }
            int col = colY[0] <= colY[1] ? 0 : 1;
            c.x = vx() + col * (cw + GAP);
            c.y = vy() + colY[col] - (int) scroll;
            colY[col] += c.h + GAP;
            out.add(c);
        }
        int content = Math.max(colY[0], colY[1]);
        maxScroll = Math.max(0, content - vh());
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;
        return out;
    }

    private List<Side> sidebar() {
        List<Side> l = new ArrayList<>();
        int y = py + 44;
        for (Group g : Group.values()) {
            Side h = new Side();
            h.g = g;
            h.y = y;
            l.add(h);
            y += 12;
            if (!collapsed[g.ordinal()]) {
                for (Page p : Page.values()) {
                    if (p.group != g) continue;
                    Side s = new Side();
                    s.g = g;
                    s.p = p;
                    s.y = y;
                    l.add(s);
                    y += 13;
                }
            }
            y += 4;
        }
        return l;
    }

    private int[] filterRect() {
        int w = 8 + (int) Ui.widthScaled("Отображение", 0.85f) + 5 + 11;
        return new int[]{px + PW - 10 - w, py + 6, w, 12};
    }

    private int[] collapseRect() {
        int[] f = filterRect();
        int w = 8 + (int) Ui.widthScaled("Свернуть всё", 0.85f);
        return new int[]{f[0] - 12 - w, py + 6, w, 12};
    }

    private int[] bottomBtn(int i) {
        return new int[]{px + 6 + i * 32, py + PH - 24, 28, 16};
    }

    private void scissor(int x, int y, int w, int h) {
        Window win = MinecraftClient.getInstance().getWindow();
        double s = win.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (x * s), (int) (win.getFramebufferHeight() - (y + h) * s), (int) (w * s), (int) (h * s));
    }

    // ---------- render ----------
    @Override
    public void render(MatrixStack m, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        float k = 1f - (float) Math.exp(-dt * 18f);

        if (dim) fillGradient(m, 0, 0, width, height, 0x55000000, 0x77000000);

        Ui.rrect(m, px - 2, py - 2, PW + 4, PH + 4, 7, 0x30000000);
        Ui.rbox(m, px, py, PW, PH, 5, Ui.PANEL, Ui.PANEL_BORDER);
        Ui.fill(m, px + SB, py + 8, px + SB + 1, py + PH - 8, Ui.PANEL_BORDER);

        renderSidebar(m, mx, my);
        renderTop(m, mx, my);

        List<Card> cards = layout();
        scissor(px + SB + 1, py + TOP + 2, PW - SB - 2, PH - TOP - 5);
        for (Card c : cards) {
            c.m.anim += ((c.m.enabled ? 1f : 0f) - c.m.anim) * k;
            for (Setting s : c.m.settings) {
                if (!s.slider) s.anim += ((s.value ? 1f : 0f) - s.anim) * k;
            }
            renderCard(m, c, mx, my);
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        if (cards.isEmpty()) {
            String s = "Ничего не найдено";
            Ui.text(m, s, vx() + (vw() - Ui.width(s)) / 2f, vy() + 40, Ui.MUTED);
        }

        if (maxScroll > 0) {
            int trackH = vh();
            int barH = Math.max(16, (int) (trackH * (trackH / (trackH + maxScroll))));
            int barY = vy() + (int) ((trackH - barH) * (scroll / maxScroll));
            Ui.rrect(m, px + PW - 6, barY, 2, barH, 1, 0xFF3A4258);
        }

        super.render(m, mx, my, delta);
    }

    private void renderSidebar(MatrixStack m, int mx, int my) {
        // logo
        int lx = px + SB / 2 - 7, ly = py + 8;
        Ui.rrect(m, lx, ly, 14, 14, 4, Ui.accent());
        Ui.text(m, "C", lx + 4, ly + 3, 0xFFFFFFFF);

        // user
        String user = MinecraftClient.getInstance().getSession().getUsername();
        Ui.textScaled(m, user, px + 12, py + 29, Ui.TEXT, 0.8f);
        String off = "offline";
        Ui.textScaled(m, off, px + SB - 10 - Ui.widthScaled(off, 0.8f), py + 29, Ui.MUTED, 0.8f);

        for (Side s : sidebar()) {
            if (s.p == null) {
                Ui.textScaled(m, s.g.title, px + 8, s.y + 2, Ui.MUTED, 0.8f);
                Ui.textScaled(m, collapsed[s.g.ordinal()] ? ">" : "v",
                        px + 8 + Ui.widthScaled(s.g.title, 0.8f) + 4, s.y + 2, Ui.MUTED, 0.7f);
            } else {
                boolean sel = s.p == page && query.trim().isEmpty();
                boolean hov = Ui.inside(mx, my, px + 6, s.y, SB - 12, 13);
                if (sel) Ui.rrect(m, px + 6, s.y, SB - 12, 13, 3, Ui.SIDE_SEL);
                else if (hov) Ui.rrect(m, px + 6, s.y, SB - 12, 13, 3, Ui.CARD);
                Ui.rrect(m, px + 11, s.y + 4, 5, 5, 2, sel ? Ui.accent() : Ui.DIM);
                Ui.text(m, s.p.title, px + 21, s.y + 3, sel ? Ui.TEXT : 0xFFB7BDCB);
            }
        }

        // bottom buttons: search / theme / background
        for (int i = 0; i < 3; i++) {
            int[] b = bottomBtn(i);
            boolean hov = Ui.inside(mx, my, b[0], b[1], b[2], b[3]);
            boolean active = (i == 0 && searching) || (i == 2 && dim);
            Ui.rbox(m, b[0], b[1], b[2], b[3], 3, hov ? Ui.CARD_HOVER : Ui.CARD, active ? Ui.accent() : Ui.CARD_BORDER);
            int cx = b[0] + b[2] / 2, cy = b[1] + b[3] / 2;
            if (i == 0) {
                Ui.fill(m, cx - 4, cy - 4, cx + 1, cy - 3, Ui.MUTED);
                Ui.fill(m, cx - 4, cy, cx + 1, cy + 1, Ui.MUTED);
                Ui.fill(m, cx - 4, cy - 4, cx - 3, cy + 1, Ui.MUTED);
                Ui.fill(m, cx, cy - 4, cx + 1, cy + 1, Ui.MUTED);
                Ui.fill(m, cx + 1, cy + 1, cx + 3, cy + 3, Ui.MUTED);
            } else if (i == 1) {
                Ui.rrect(m, cx - 4, cy - 4, 8, 8, 4, Ui.accent());
            } else {
                Ui.fill(m, cx - 4, cy - 3, cx + 4, cy - 2, Ui.MUTED);
                Ui.fill(m, cx - 4, cy, cx + 4, cy + 1, Ui.MUTED);
                Ui.fill(m, cx - 4, cy + 3, cx + 4, cy + 4, Ui.MUTED);
                Ui.fill(m, cx - 1, cy - 4, cx + 1, cy - 1, Ui.TEXT);
                Ui.fill(m, cx + 1, cy - 1, cx + 3, cy + 2, Ui.TEXT);
            }
        }
    }

    private void renderTop(MatrixStack m, int mx, int my) {
        int bx = px + SB + 8;
        if (searching || !query.isEmpty()) {
            Ui.rbox(m, bx, py + 4, 170, 15, 3, Ui.CARD, searching ? Ui.accent() : Ui.CARD_BORDER);
            String shown = query + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            if (query.isEmpty() && shown.isEmpty()) {
                Ui.textScaled(m, "Поиск по модулям...", bx + 6, py + 9, Ui.MUTED, 0.85f);
            } else {
                Ui.text(m, shown, bx + 6, py + 8, Ui.TEXT);
            }
        } else {
            String g = page.group.title + " /";
            Ui.textScaled(m, g, bx, py + 9, Ui.MUTED, 0.85f);
            int gx = bx + (int) Ui.widthScaled(g, 0.85f) + 5;
            Ui.rrect(m, gx, py + 10, 5, 5, 2, Ui.accent());
            Ui.textScaled(m, page.title, gx + 9, py + 9, Ui.TEXT, 0.85f);
        }

        // collapse all
        int[] c = collapseRect();
        boolean hc = Ui.inside(mx, my, c[0], c[1], c[2], c[3]);
        int cc = hc ? Ui.TEXT : Ui.MUTED;
        Ui.fill(m, c[0], c[1] + 3, c[0] + 5, c[1] + 4, cc);
        Ui.fill(m, c[0], c[1] + 8, c[0] + 5, c[1] + 9, cc);
        Ui.textScaled(m, "Свернуть всё", c[0] + 8, c[1] + 2.5f, cc, 0.85f);

        // display filter
        int[] f = filterRect();
        boolean hf = Ui.inside(mx, my, f[0], f[1], f[2], f[3]);
        int fc = hf ? Ui.TEXT : Ui.MUTED;
        Ui.fill(m, f[0], f[1] + 3, f[0] + 6, f[1] + 4, fc);
        Ui.fill(m, f[0] + 1, f[1] + 5, f[0] + 5, f[1] + 6, fc);
        Ui.fill(m, f[0] + 2, f[1] + 7, f[0] + 4, f[1] + 8, fc);
        Ui.textScaled(m, "Отображение", f[0] + 8, f[1] + 2.5f, fc, 0.85f);
        Ui.rrect(m, f[0] + f[2] - 11, f[1] + 1, 11, 10, 2, 0xFF0B0E14);
        String cnt = String.valueOf(filter + 1);
        Ui.textScaled(m, cnt, f[0] + f[2] - 11 + (11 - Ui.widthScaled(cnt, 0.8f)) / 2f, f[1] + 3, Ui.TEXT, 0.8f);
    }

    private void renderCard(MatrixStack m, Card c, int mx, int my) {
        boolean hov = Ui.inside(mx, my, c.x, c.y, c.w, c.h)
                && Ui.inside(mx, my, px + SB + 1, py + TOP + 2, PW - SB - 2, PH - TOP - 5);
        Ui.rbox(m, c.x, c.y, c.w, c.h, 4, hov ? Ui.CARD_HOVER : Ui.CARD, Ui.CARD_BORDER);

        Ui.text(m, c.m.name, c.x + 8, c.y + 7, Ui.TEXT);
        for (int i = 0; i < c.lines.size(); i++) {
            Ui.textScaled(m, c.lines.get(i), c.x + 8, c.y + 19 + i * 8, Ui.MUTED, 0.8f);
        }

        boolean has = !c.m.settings.isEmpty();
        int rx = c.x + c.w - 7;
        int ax = rx - 12;
        int tx = rx - (has ? 18 : 0) - 18;

        // bind icon
        Ui.rrect(m, tx - 12, c.y + 9, 8, 5, 1, Ui.DIM);

        // toggle
        Ui.toggle(m, tx, c.y + 6, c.m.anim);

        // arrow button
        if (has) {
            boolean ha = Ui.inside(mx, my, ax - 1, c.y + 4, 14, 14);
            Ui.rbox(m, ax, c.y + 5, 12, 12, 3, ha ? Ui.CARD_HOVER : Ui.CARD, Ui.CARD_BORDER);
            String a = c.m.expanded ? "v" : ">";
            Ui.textScaled(m, a, ax + (12 - Ui.widthScaled(a, 0.8f)) / 2f, c.y + 8.5f, Ui.MUTED, 0.8f);
        }

        // settings
        if (c.m.expanded && has) {
            int sy = c.y + c.headH;
            Ui.fill(m, c.x + 6, sy, c.x + c.w - 6, sy + 1, Ui.CARD_BORDER);
            int y = sy + 5;
            for (Setting s : c.m.settings) {
                if (!s.slider) {
                    Ui.textScaled(m, s.name, c.x + 8, y + 3, 0xFFB7BDCB, 0.9f);
                    Ui.toggle(m, c.x + c.w - 8 - 18, y + 1, s.anim);
                } else {
                    Ui.textScaled(m, s.name, c.x + 8, y + 1, 0xFFB7BDCB, 0.9f);
                    String v = s.display();
                    Ui.textScaled(m, v, c.x + c.w - 8 - Ui.widthScaled(v, 0.9f), y + 1, Ui.TEXT, 0.9f);
                    int tw = c.w - 16;
                    double t = (s.num - s.min) / (s.max - s.min);
                    int fw = (int) Math.round(tw * t);
                    Ui.rrect(m, c.x + 8, y + 13, tw, 3, 1, Ui.OFF_TRACK);
                    if (fw > 0) Ui.rrect(m, c.x + 8, y + 13, fw, 3, 1, Ui.accent());
                    Ui.rrect(m, c.x + 8 + fw - 2, y + 11, 5, 7, 2, 0xFFFFFFFF);
                }
                y += rowH(s);
            }
        }
    }

    // ---------- input ----------
    private void applySlider(double mx) {
        if (dragging == null) return;
        double t = (mx - dragX0) / (double) (dragX1 - dragX0);
        t = Math.max(0, Math.min(1, t));
        double v = dragging.min + t * (dragging.max - dragging.min);
        double step = dragging.step();
        v = Math.round(v / step) * step;
        dragging.num = Math.max(dragging.min, Math.min(dragging.max, v));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // sidebar
        for (Side s : sidebar()) {
            if (!Ui.inside(mx, my, px + 6, s.y, SB - 12, s.p == null ? 12 : 13)) continue;
            if (button != 0) return true;
            if (s.p == null) {
                collapsed[s.g.ordinal()] = !collapsed[s.g.ordinal()];
            } else {
                page = s.p;
                scroll = 0;
                query = "";
                searching = false;
            }
            return true;
        }

        if (button == 0) {
            for (int i = 0; i < 3; i++) {
                int[] b = bottomBtn(i);
                if (!Ui.inside(mx, my, b[0], b[1], b[2], b[3])) continue;
                if (i == 0) {
                    searching = !searching;
                    if (!searching) query = "";
                    scroll = 0;
                } else if (i == 1) {
                    Ui.accentIdx = (Ui.accentIdx + 1) % Ui.ACCENTS.length;
                } else {
                    dim = !dim;
                }
                return true;
            }
            int[] c = collapseRect();
            if (Ui.inside(mx, my, c[0], c[1], c[2], c[3])) {
                for (Module mod : source()) mod.expanded = false;
                return true;
            }
            int[] f = filterRect();
            if (Ui.inside(mx, my, f[0], f[1], f[2], f[3])) {
                filter = (filter + 1) % 3;
                scroll = 0;
                return true;
            }
            if ((searching || !query.isEmpty()) && Ui.inside(mx, my, px + SB + 8, py + 4, 170, 15)) {
                searching = true;
                return true;
            }
        }

        // cards
        if (Ui.inside(mx, my, px + SB + 1, py + TOP + 2, PW - SB - 2, PH - TOP - 5)) {
            for (Card c : layout()) {
                if (!Ui.inside(mx, my, c.x, c.y, c.w, c.h)) continue;
                boolean has = !c.m.settings.isEmpty();
                int rx = c.x + c.w - 7;
                int ax = rx - 12;
                if (my < c.y + c.headH) {
                    if (has && (button == 1 || (button == 0 && Ui.inside(mx, my, ax - 1, c.y + 4, 14, 14)))) {
                        c.m.expanded = !c.m.expanded;
                    } else if (button == 0) {
                        c.m.enabled = !c.m.enabled;
                    }
                    return true;
                }
                if (button == 0 && c.m.expanded) {
                    int y = c.y + c.headH + 5;
                    for (Setting s : c.m.settings) {
                        int h = rowH(s);
                        if (my >= y && my < y + h) {
                            if (s.slider) {
                                dragging = s;
                                dragX0 = c.x + 8;
                                dragX1 = c.x + c.w - 8;
                                applySlider(mx);
                            } else {
                                s.value = !s.value;
                            }
                            return true;
                        }
                        y += h;
                    }
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            applySlider(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - amount * 18));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (searching) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                scroll = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) {
                searching = false;
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char chr, int mods) {
        if (searching && chr >= 32 && query.length() < 24) {
            query += chr;
            scroll = 0;
            return true;
        }
        return super.charTyped(chr, mods);
    }
}
