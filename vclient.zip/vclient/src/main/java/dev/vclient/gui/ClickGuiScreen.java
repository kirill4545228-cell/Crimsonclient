package dev.vclient.gui;

import dev.vclient.module.Category;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
    private static final int PW = 340, PH = 240;
    private static final int HEADER = 16, BODY = 16, GAP = 6;

    private static Category selected = Category.VISUALS;
    private static double scroll = 0;
    private double maxScroll = 0;
    private boolean searching = false;
    private String query = "";
    private int px, py;

    private static class Card {
        Module m;
        int x, y, w, h;
    }

    public ClickGuiScreen() {
        super(new LiteralText("VClient"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;
    }

    private int vx() { return px + 40; }
    private int vy() { return py + 32; }
    private int vw() { return PW - 48; }
    private int vh() { return PH - 38; }

    private List<Card> layout() {
        List<Card> out = new ArrayList<>();
        int cw = (vw() - GAP) / 2;
        int[] colY = {0, 0};
        String q = query.toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.get(selected)) {
            if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            int col = colY[0] <= colY[1] ? 0 : 1;
            Card c = new Card();
            c.m = m;
            c.w = cw;
            c.h = m.expanded ? HEADER + BODY : HEADER;
            c.x = vx() + col * (cw + GAP);
            c.y = vy() + 3 + colY[col] - (int) scroll;
            colY[col] += c.h + GAP;
            out.add(c);
        }
        int content = Math.max(colY[0], colY[1]);
        maxScroll = Math.max(0, content - vh() + 3);
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;
        return out;
    }

    private void scissor(int x, int y, int w, int h) {
        Window win = MinecraftClient.getInstance().getWindow();
        double s = win.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (x * s), (int) (win.getFramebufferHeight() - (y + h) * s), (int) (w * s), (int) (h * s));
    }

    @Override
    public void render(MatrixStack m, int mx, int my, float delta) {
        fillGradient(m, 0, 0, width, height, 0x66000000, 0xAA3A0010);

        Ui.glowBox(m, px, py, PW, PH, Ui.PANEL, Ui.LINE);
        Ui.fill(m, px + 1, py + 26, px + PW - 1, py + 27, Ui.LINE);
        Ui.fill(m, px + 34, py + 27, px + 35, py + PH - 1, Ui.LINE);

        renderTopBar(m, mx, my);
        renderSidebar(m, mx, my);

        List<Card> cards = layout();
        scissor(vx() - 2, vy(), vw() + 4, vh());
        for (Card c : cards) renderCard(m, c, mx, my);
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        if (cards.isEmpty()) {
            String s = query.isEmpty() ? "Soon" : "Nothing found";
            Ui.text(m, s, vx() + (vw() - Ui.width(s)) / 2f, vy() + 40, Ui.GRAY);
        }

        if (maxScroll > 0) {
            int trackH = vh() - 4;
            int barH = Math.max(14, (int) (trackH * (trackH / (trackH + maxScroll))));
            int barY = vy() + 2 + (int) ((trackH - barH) * (scroll / maxScroll));
            Ui.fill(m, px + PW - 5, barY, px + PW - 3, barY + barH, Ui.ACCENT);
        }

        super.render(m, mx, my, delta);
    }

    private void renderTopBar(MatrixStack m, int mx, int my) {
        int hx = px + 8, hy = py + 5;
        Ui.fill(m, hx, hy, hx + 16, hy + 16, Ui.CARD);
        Ui.outline(m, hx, hy, 16, 16, Ui.inside(mx, my, hx, hy, 16, 16) ? Ui.ACCENT : Ui.LINE);
        Ui.text(m, "H", hx + 5, hy + 4, Ui.GRAY);

        int sx = px + 30, sy = py + 5, sw = searching || !query.isEmpty() ? 100 : 16;
        Ui.fill(m, sx, sy, sx + sw, sy + 16, Ui.CARD);
        Ui.outline(m, sx, sy, sw, 16, searching ? Ui.ACCENT : Ui.LINE);
        if (sw == 16) {
            Ui.text(m, "?", sx + 5, sy + 4, Ui.GRAY);
        } else {
            String shown = query + (searching && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            if (shown.isEmpty()) shown = "Search...";
            Ui.text(m, shown, sx + 5, sy + 4, query.isEmpty() ? Ui.GRAY : Ui.WHITE);
        }

        String tab = selected.title;
        int tx = sx + sw + 6;
        int tw = Ui.width(tab) + 12;
        Ui.fill(m, tx, sy, tx + tw, sy + 16, Ui.CARD);
        Ui.outline(m, tx, sy, tw, 16, Ui.LINE);
        Ui.text(m, tab, tx + 6, sy + 4, Ui.GRAY);

        String user = MinecraftClient.getInstance().getSession().getUsername();
        int uw = 78;
        int ux = px + PW - uw - 8;
        Ui.fill(m, ux, sy, ux + uw, sy + 16, Ui.CARD);
        Ui.outline(m, ux, sy, uw, 16, Ui.LINE);
        Ui.fill(m, ux + 5, sy + 4, ux + 13, sy + 12, 0xFF2A2A2E);
        Ui.textScaled(m, user, ux + 17, sy + 3, Ui.WHITE, 0.7f);
        Ui.textScaled(m, "USER", ux + 17, sy + 9, Ui.ACCENT, 0.6f);
    }

    private void renderSidebar(MatrixStack m, int mx, int my) {
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = px + 7, y = py + 34 + i * 28;
            boolean sel = cats[i] == selected;
            boolean hov = Ui.inside(mx, my, x, y, 22, 22);
            if (sel) {
                Ui.glowBox(m, x, y, 22, 22, Ui.CARD, Ui.ACCENT);
            } else if (hov) {
                Ui.fill(m, x, y, x + 22, y + 22, Ui.CARD_HOVER);
            }
            String ic = cats[i].icon;
            Ui.text(m, ic, x + 11 - Ui.width(ic) / 2f, y + 7, sel ? Ui.WHITE : Ui.GRAY);
        }
    }

    private void renderCard(MatrixStack m, Card c, int mx, int my) {
        boolean hov = Ui.inside(mx, my, c.x, c.y, c.w, c.h) && Ui.inside(mx, my, vx(), vy(), vw(), vh());
        Ui.glowBox(m, c.x, c.y, c.w, c.h, hov ? Ui.CARD_HOVER : Ui.CARD, Ui.ACCENT);

        Ui.text(m, c.m.expanded ? "v" : ">", c.x + 5, c.y + 4, Ui.GRAY);
        Ui.text(m, c.m.name, c.x + 15, c.y + 4, Ui.WHITE);
        int bw = 20, bx = c.x + c.w - bw - 5, by = c.y + 4;
        Ui.fill(m, bx, by, bx + bw, by + 9, Ui.BADGE);
        Ui.textScaled(m, c.m.bind, bx + (bw - Ui.width(c.m.bind) * 0.75f) / 2f, by + 1.5f, Ui.GRAY, 0.75f);

        if (c.m.expanded) {
            Ui.fill(m, c.x + 1, c.y + HEADER - 1, c.x + c.w - 1, c.y + HEADER, 0x30FFFFFF);
            Ui.text(m, "Enable", c.x + 6, c.y + HEADER + 4, Ui.WHITE);
            Ui.checkbox(m, c.x + c.w - 14, c.y + HEADER + 4, c.m.enabled);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        if (Ui.inside(mx, my, px + 8, py + 5, 16, 16)) {
            selected = Category.VISUALS;
            scroll = 0;
            query = "";
            searching = false;
            return true;
        }
        int sw = searching || !query.isEmpty() ? 100 : 16;
        if (Ui.inside(mx, my, px + 30, py + 5, sw, 16)) {
            searching = !searching || sw == 16;
            return true;
        }
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (Ui.inside(mx, my, px + 7, py + 34 + i * 28, 22, 22)) {
                selected = cats[i];
                scroll = 0;
                return true;
            }
        }
        if (Ui.inside(mx, my, vx(), vy(), vw(), vh())) {
            for (Card c : layout()) {
                if (!Ui.inside(mx, my, c.x, c.y, c.w, c.h)) continue;
                if (my < c.y + HEADER) {
                    c.m.expanded = !c.m.expanded;
                } else {
                    c.m.enabled = !c.m.enabled;
                }
                return true;
            }
        }
        searching = false;
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - amount * 14));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (searching) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                scroll = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) {
                searching = false;
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char chr, int mods) {
        if (searching && chr >= 32 && query.length() < 20) {
            query += chr;
            scroll = 0;
            return true;
        }
        return super.charTyped(chr, mods);
    }
}
