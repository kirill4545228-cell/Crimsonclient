package dev.vclient.mixin;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    /** BetterCrosshair: прячет ванильный прицел. */
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void vclient$crosshair(MatrixStack matrices, CallbackInfo ci) {
        Module m = ModuleManager.get("BetterCrosshair");
        if (m != null && m.enabled && m.getBool("Скрыть ванильный")) ci.cancel();
    }
}
