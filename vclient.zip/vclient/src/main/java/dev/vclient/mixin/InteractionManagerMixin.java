package dev.vclient.mixin;

import dev.vclient.module.ModuleManager;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class InteractionManagerMixin {
    /** Reach: расширенная дистанция (как в креативе, до 6 блоков). */
    @Inject(method = "hasExtendedReach", at = @At("HEAD"), cancellable = true)
    private void vclient$reach(CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.isEnabled("Reach")) cir.setReturnValue(true);
    }
}
