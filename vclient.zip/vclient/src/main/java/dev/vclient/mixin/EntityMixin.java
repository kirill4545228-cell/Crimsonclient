package dev.vclient.mixin;

import dev.vclient.features.Esp;
import dev.vclient.features.Targets;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {

    /** HitBox: расширяет область, по которой прицел «видит» цель. */
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void vclient$margin(CallbackInfoReturnable<Float> cir) {
        Entity self = (Entity) (Object) this;
        if (self.world == null || !self.world.isClient) return;
        Module m = ModuleManager.get("HitBox");
        if (m == null || !m.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return;
        if (Targets.valid(m, self, mc.player)) {
            cir.setReturnValue((float) m.num("Размер"));
        }
    }

    /** ESP: включает обводку свечения. */
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void vclient$glow(CallbackInfoReturnable<Boolean> cir) {
        if (Esp.applies((Entity) (Object) this)) cir.setReturnValue(true);
    }

    /** ESP: цвет обводки. */
    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void vclient$color(CallbackInfoReturnable<Integer> cir) {
        if (Esp.applies((Entity) (Object) this)) cir.setReturnValue(Esp.color());
    }
}
