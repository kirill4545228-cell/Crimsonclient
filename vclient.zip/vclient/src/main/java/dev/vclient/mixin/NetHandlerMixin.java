package dev.vclient.mixin;

import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class NetHandlerMixin {
    /** Velocity: масштабирует (или гасит) отбрасывание игрока. */
    @Inject(method = "onVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void vclient$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        Module m = ModuleManager.get("Velocity");
        if (m == null || !m.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || !mc.isOnThread()) return;
        if (packet.getId() != mc.player.getEntityId()) return;
        double h = m.num("Горизонталь, %") / 100.0, v = m.num("Вертикаль, %") / 100.0;
        mc.player.setVelocity(packet.getVelocityX() / 8000.0 * h, packet.getVelocityY() / 8000.0 * v,
                packet.getVelocityZ() / 8000.0 * h);
        ci.cancel();
    }
}
