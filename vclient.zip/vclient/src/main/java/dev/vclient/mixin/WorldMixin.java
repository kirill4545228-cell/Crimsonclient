package dev.vclient.mixin;

import dev.vclient.module.ModuleManager;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public abstract class WorldMixin {
    /** No Rain: визуально отключает дождь. */
    @Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true)
    private void vclient$rain(float delta, CallbackInfoReturnable<Float> cir) {
        if (((World) (Object) this).isClient && ModuleManager.isEnabled("No Rain")) cir.setReturnValue(0f);
    }

    @Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true)
    private void vclient$thunder(float delta, CallbackInfoReturnable<Float> cir) {
        if (((World) (Object) this).isClient && ModuleManager.isEnabled("No Rain")) cir.setReturnValue(0f);
    }
}
