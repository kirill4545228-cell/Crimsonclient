package dev.vclient.hud;

import dev.vclient.gui.Ui;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;

public final class Hud {
    private static long last = System.nanoTime();
    private static float fps = 60f;

    private Hud() {}

    public static void render(MatrixStack m, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || !ModuleManager.isEnabled("HUD")) return;

        long now = System.nanoTime();
        float inst = 1_000_000_000f / Math.max(1L, now - last);
        last = now;
        fps += (inst - fps) * 0.05f;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        pill(m, 6, 6, new String[]{"VCLIENT", "USER", mc.getSession().getUsername(), (int) fps + " FPS"});

        String where = mc.isInSingleplayer() ? "Singleplayer"
                : (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "Server");
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        pill(m, 6, 26, new String[]{where, ping + " ms"});

        double dx = mc.player.getX() - mc.player.prevX;
        double dz = mc.player.getZ() - mc.player.prevZ;
        double bps = Math.sqrt(dx * dx + dz * dz) * 20.0;
        int bx = mc.player.getBlockPos().getX(), by = mc.player.getBlockPos().getY(), bz = mc.player.getBlockPos().getZ();
        pill(m, 4, sh - 22, new String[]{String.format("%.1f BPS", bps), bx + ", " + by + ", " + bz});

        List<String> names = new ArrayList<>();
        for (Module mod : ModuleManager.all()) {
            if (mod.enabled && !mod.name.equals("HUD")) names.add(mod.name);
        }
        names.sort((a, b) -> Ui.width(b) - Ui.width(a));
        int y = 3;
        for (String n : names) {
            int w = Ui.width(n);
            Ui.fill(m, sw - w - 6, y - 1, sw - 2, y + 10, 0x90100409);
            Ui.fill(m, sw - 2, y - 1, sw, y + 10, Ui.ACCENT);
            Ui.text(m, n, sw - w - 4, y + 1, Ui.ACCENT);
            y += 11;
        }
    }

    private static void pill(MatrixStack m, int x, int y, String[] parts) {
        int w = 6;
        for (String p : parts) w += Ui.width(p) + 11;
        w -= 5;
        Ui.glowBox(m, x, y, w, 16, 0xD0100409, Ui.LINE);
        int cx = x + 6;
        for (int i = 0; i < parts.length; i++) {
            Ui.text(m, parts[i], cx, y + 4, i == 0 ? Ui.ACCENT : Ui.WHITE);
            cx += Ui.width(parts[i]) + 5;
            if (i < parts.length - 1) {
                Ui.fill(m, cx, y + 3, cx + 1, y + 13, Ui.LINE);
                cx += 6;
            }
        }
    }
}
