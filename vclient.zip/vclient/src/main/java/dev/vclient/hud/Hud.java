package dev.vclient.hud;

import dev.vclient.gui.Ui;
import dev.vclient.module.Module;
import dev.vclient.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;

public final class Hud {
    private static long last = System.nanoTime();
    private static float fps = 60f;

    private Hud() {}

    public static void render(MatrixStack m, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Module hud = ModuleManager.get("HUD");
        if (mc.player == null || mc.options.hudHidden || hud == null || !hud.enabled) return;

        long now = System.nanoTime();
        float inst = 1_000_000_000f / Math.max(1L, now - last);
        last = now;
        fps += (inst - fps) * 0.05f;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        if (hud.getBool("Информация")) {
            pill(m, 6, 6, new String[]{"VCLIENT", mc.getSession().getUsername(), (int) fps + " FPS"});

            String where = mc.isInSingleplayer() ? "Singleplayer"
                    : (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "Server");
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            pill(m, 6, 26, new String[]{where, ping + " ms"});
        }

        if (hud.getBool("Координаты")) {
            double dx = mc.player.getX() - mc.player.prevX;
            double dz = mc.player.getZ() - mc.player.prevZ;
            double bps = Math.sqrt(dx * dx + dz * dz) * 20.0;
            int bx = mc.player.getBlockPos().getX(), by = mc.player.getBlockPos().getY(), bz = mc.player.getBlockPos().getZ();
            pill(m, 4, sh - 22, new String[]{String.format("%.1f BPS", bps), bx + ", " + by + ", " + bz});
        }

        if (hud.getBool("Список модулей")) {
            List<String> names = new ArrayList<>();
            for (Module mod : ModuleManager.all()) {
                if (mod.enabled && !mod.name.equals("HUD")) names.add(mod.name);
            }
            names.sort((a, b) -> Ui.width(b) - Ui.width(a));
            int y = 4;
            for (String n : names) {
                int w = Ui.width(n);
                Ui.rrect(m, sw - w - 12, y, w + 10, 12, 3, 0xE0131822);
                Ui.rrect(m, sw - 4, y + 2, 2, 8, 1, Ui.accent());
                Ui.text(m, n, sw - w - 8, y + 2, Ui.TEXT);
                y += 14;
            }
        }
    }

    private static void pill(MatrixStack m, int x, int y, String[] parts) {
        int w = 12;
        for (String p : parts) w += Ui.width(p) + 11;
        w -= 11;
        Ui.rbox(m, x, y, w, 16, 4, Ui.PANEL, Ui.PANEL_BORDER);
        int cx = x + 6;
        for (int i = 0; i < parts.length; i++) {
            Ui.text(m, parts[i], cx, y + 4, i == 0 ? Ui.accent() : Ui.TEXT);
            cx += Ui.width(parts[i]) + 5;
            if (i < parts.length - 1) {
                Ui.fill(m, cx, y + 4, cx + 1, y + 12, Ui.PANEL_BORDER);
                cx += 6;
            }
        }
    }
}
