# VClient (Fabric 1.16.5)
Visual part: ClickGUI + HUD. Open menu: Right Shift.
Build: `gradle build` (JDK 17, Gradle 7.6.x) -> build/libs/vclient-*.jar
